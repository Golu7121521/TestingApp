package org.schabi.newpipe.info_list.holder;

import android.view.ViewGroup;
import android.widget.ImageView;

import org.schabi.newpipe.R;
import org.schabi.newpipe.extractor.InfoItem;
import org.schabi.newpipe.extractor.stream.StreamInfoItem;
import org.schabi.newpipe.info_list.InfoItemBuilder;
import org.schabi.newpipe.local.history.HistoryRecordManager;
import org.schabi.newpipe.util.image.CoilHelper;

/**
 * Card layout for stream: full-width thumbnail with the uploader avatar next to the title.
 */
public class StreamCardInfoItemHolder extends StreamInfoItemHolder {

    private final ImageView itemUploaderAvatar;

    public StreamCardInfoItemHolder(final InfoItemBuilder infoItemBuilder, final ViewGroup parent) {
        super(infoItemBuilder, R.layout.list_stream_card_item, parent);
        itemUploaderAvatar = itemView.findViewById(R.id.itemUploaderAvatar);
    }

    @Override
    public void updateFromItem(final InfoItem infoItem,
                               final HistoryRecordManager historyRecordManager) {
        super.updateFromItem(infoItem, historyRecordManager);

        if (infoItem instanceof StreamInfoItem && itemUploaderAvatar != null) {
            CoilHelper.INSTANCE.loadAvatar(itemUploaderAvatar,
                    ((StreamInfoItem) infoItem).getUploaderAvatars());
        }
    }
}
