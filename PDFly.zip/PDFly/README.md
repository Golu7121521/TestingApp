# PDFly

Android PDF app (Kotlin + Jetpack Compose). Light-blue theme, light/dark mode.
PDF pages are rendered with Google's `android.graphics.pdf.PdfRenderer`.

Features: library, viewer (zoom, page jump, thumbnails, print), merge, split, compress,
images<->PDF, draw/highlight, sign, organize pages.

Accent colour lives in `app/src/main/java/com/pdfly/app/ui/Theme.kt` (`object Accent`).

Build: push to GitHub -> Actions builds a signed arm64-v8a APK and attaches it to a Release.
The keystore in `app/pdfly.jks` is a throwaway key so updates install over older builds.
