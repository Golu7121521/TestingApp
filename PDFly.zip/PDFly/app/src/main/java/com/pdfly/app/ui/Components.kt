package com.pdfly.app.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material.icons.outlined.FileUpload
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import com.pdfly.app.data.AppViewModel
import com.pdfly.app.data.PdfItem
import com.pdfly.app.data.Thumbs
import com.pdfly.app.data.ToastKind
import com.pdfly.app.data.ToastMsg
import kotlinx.coroutines.delay
import java.io.File

enum class BtnStyle { Primary, Secondary, Danger, Ghost }

@Composable
fun PButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    style: BtnStyle = BtnStyle.Primary,
    enabled: Boolean = true,
) {
    val c = Pdfly.colors
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val bg = when (style) {
        BtnStyle.Primary -> if (pressed) c.primaryActive else c.primary
        BtnStyle.Secondary -> if (pressed) c.divider else c.surface
        BtnStyle.Danger -> if (pressed) Color(0xFFDC2626) else c.error
        BtnStyle.Ghost -> if (pressed) c.primarySoft else Color.Transparent
    }
    val fg = when (style) {
        BtnStyle.Primary -> if (pressed) Color.White else c.onPrimary
        BtnStyle.Secondary -> c.text
        BtnStyle.Danger -> Color.White
        BtnStyle.Ghost -> c.accentText
    }
    val scale = if (pressed) 0.98f else 1f
    Row(
        modifier = modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .alpha(if (enabled) 1f else 0.45f)
            .height(44.dp)
            .clip(Radius.md)
            .background(bg)
            .then(if (style == BtnStyle.Secondary) Modifier.border(1.dp, c.border, Radius.md) else Modifier)
            .clickable(interactionSource = src, indication = null, enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) Icon(icon, null, tint = fg, modifier = Modifier.size(18.dp))
        Text(text, style = Type.button, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun IconBtn(
    icon: ImageVector,
    desc: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = Pdfly.colors.textSecondary,
    enabled: Boolean = true,
    size: Dp = 44.dp,
    background: Color = Color.Transparent,
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(Radius.md)
            .background(background)
            .alpha(if (enabled) 1f else 0.4f)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .semantics { contentDescription = desc },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp))
    }
}

@Composable
fun SurfaceCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    padding: Dp = 16.dp,
    content: @Composable () -> Unit,
) {
    val c = Pdfly.colors
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val lift = if (onClick != null && pressed) -2f else 0f
    Box(
        modifier = modifier
            .graphicsLayer { translationY = lift * density }
            .clip(Radius.lg)
            .background(c.surface)
            .border(1.dp, if (onClick != null && pressed) c.primaryBorder else c.border, Radius.lg)
            .then(if (onClick != null) Modifier.clickable(interactionSource = src, indication = null, role = Role.Button, onClick = onClick) else Modifier)
            .padding(padding),
    ) { content() }
}

@Composable
fun IconTile(icon: ImageVector, size: Dp = 44.dp, iconSize: Dp = 22.dp) {
    val c = Pdfly.colors
    Box(
        Modifier.size(size).clip(Radius.md).background(c.primarySoft).border(1.dp, c.primaryBorder.copy(alpha = if (c.dark) 0.5f else 0.7f), Radius.md),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = c.accentText, modifier = Modifier.size(iconSize)) }
}

@Composable
fun Heading(text: String, modifier: Modifier = Modifier) {
    Text(text, style = Type.section, color = Pdfly.colors.text, modifier = modifier, maxLines = 1)
}

@Composable
fun PageHeader(title: String, subtitle: String, action: (@Composable () -> Unit)? = null) {
    val c = Pdfly.colors
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = Type.pageTitle, color = c.text)
            Text(subtitle, style = Type.body, color = c.textSecondary)
        }
        action?.invoke()
    }
}

@Composable
fun PdfTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    leading: ImageVector? = null,
    singleLine: Boolean = true,
    keyboardOptions: KeyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
    onDone: (() -> Unit)? = null,
    isError: Boolean = false,
    label: String? = null,
) {
    val c = Pdfly.colors
    var focused by remember { mutableStateOf(false) }
    val border = when {
        isError -> c.error
        focused -> c.primary
        else -> c.border
    }
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = singleLine,
        textStyle = Type.body.copy(color = c.text),
        cursorBrush = SolidColor(c.primary),
        keyboardOptions = keyboardOptions,
        keyboardActions = KeyboardActions(onDone = { onDone?.invoke() }, onSearch = { onDone?.invoke() }, onGo = { onDone?.invoke() }),
        modifier = modifier
            .onFocusChanged { focused = it.isFocused }
            .semantics { if (label != null) contentDescription = label }
            .height(46.dp)
            .clip(Radius.md)
            .background(c.surface)
            .border(if (focused) 2.dp else 1.dp, border, Radius.md),
        decorationBox = { inner ->
            Row(
                Modifier.fillMaxSize().padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (leading != null) Icon(leading, null, tint = c.textMuted, modifier = Modifier.size(18.dp))
                Box(Modifier.weight(1f)) {
                    if (value.isEmpty()) Text(placeholder, style = Type.body, color = c.textMuted, maxLines = 1)
                    inner()
                }
            }
        },
    )
}

@Composable
fun StatusRow(icon: ImageVector, text: String, color: Color, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().clip(Radius.md).background(color.copy(alpha = 0.12f)).border(1.dp, color.copy(alpha = 0.4f), Radius.md)
            .padding(12.dp).semantics { liveRegion = LiveRegionMode.Polite },
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
        Text(text, style = Type.secondary, color = Pdfly.colors.text)
    }
}

@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    description: String,
    modifier: Modifier = Modifier,
    primaryLabel: String? = null,
    onPrimary: (() -> Unit)? = null,
    secondaryLabel: String? = null,
    onSecondary: (() -> Unit)? = null,
) {
    val c = Pdfly.colors
    Column(
        modifier.fillMaxWidth().padding(vertical = 32.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(Modifier.size(84.dp).clip(CircleShape).background(c.primarySoft), contentAlignment = Alignment.Center) {
            Box(Modifier.size(56.dp).clip(Radius.lg).background(c.primarySurface), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = c.accentText, modifier = Modifier.size(28.dp))
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(title, style = Type.section, color = c.text)
        Text(description, style = Type.body, color = c.textSecondary, modifier = Modifier.widthIn(max = 360.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        if (primaryLabel != null && onPrimary != null) {
            Spacer(Modifier.height(6.dp))
            PButton(primaryLabel, onPrimary)
        }
        if (secondaryLabel != null && onSecondary != null) {
            PButton(secondaryLabel, onSecondary, style = BtnStyle.Ghost)
        }
    }
}

@Composable
fun ErrorState(message: String, onRetry: (() -> Unit)?, onBack: (() -> Unit)?, backLabel: String = "Back to library") {
    EmptyState(
        icon = Icons.Outlined.ErrorOutline,
        title = "Something went wrong",
        description = message,
        primaryLabel = if (onRetry != null) "Retry" else null,
        onPrimary = onRetry,
        secondaryLabel = if (onBack != null) backLabel else null,
        onSecondary = onBack,
    )
}

@Composable
fun Skeleton(modifier: Modifier = Modifier, shape: androidx.compose.ui.graphics.Shape = Radius.md) {
    val c = Pdfly.colors
    val reduced = LocalReducedMotion.current
    val a = if (reduced) 0.7f else {
        val t = rememberInfiniteTransition(label = "sk")
        t.animateFloat(0.45f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "ska").value
    }
    Box(modifier.clip(shape).alpha(a).background(if (c.dark) c.elevated else Color(0xFFE8EEF5)))
}

@Composable
fun SkeletonList(count: Int = 4) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        repeat(count) {
            Row(
                Modifier.fillMaxWidth().height(72.dp).clip(Radius.lg).border(1.dp, Pdfly.colors.border, Radius.lg).padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Skeleton(Modifier.size(width = 36.dp, height = 48.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Skeleton(Modifier.fillMaxWidth(0.6f).height(14.dp))
                    Skeleton(Modifier.fillMaxWidth(0.4f).height(12.dp))
                }
            }
        }
    }
}

@Composable
fun ProgressBlock(label: String, progress: Float?) {
    val c = Pdfly.colors
    Column(
        Modifier.fillMaxWidth().semantics { liveRegion = LiveRegionMode.Polite },
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (progress == null) CircularProgressIndicator(Modifier.size(18.dp), color = c.primary, strokeWidth = 2.dp)
            Text(label, style = Type.secondary, color = c.textSecondary)
        }
        if (progress != null) {
            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                color = c.primary,
                trackColor = c.primarySurface,
            )
        }
    }
}

// ---------- dialogs ----------

@Composable
fun PdfDialog(
    title: String,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    description: String? = null,
    content: @Composable () -> Unit = {},
    actions: @Composable () -> Unit,
) {
    val c = Pdfly.colors
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier.fillMaxWidth().widthIn(max = 480.dp).clip(Radius.xl).background(c.elevated).border(1.dp, c.border, Radius.xl).padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(title, style = Type.section, color = c.text)
            if (description != null) Text(description, style = Type.body, color = c.textSecondary)
            content()
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.End)) { actions() }
        }
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    description: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    destructive: Boolean = true,
) {
    PdfDialog(title, onDismiss, description = description) {
        PButton("Cancel", onDismiss, style = BtnStyle.Secondary)
        PButton(confirmLabel, { onConfirm() }, style = if (destructive) BtnStyle.Danger else BtnStyle.Primary)
    }
}

@Composable
fun TextInputDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> String?, // returns an error message, or null when accepted
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    var error by remember { mutableStateOf<String?>(null) }
    val submit = {
        val err = if (text.isBlank()) "Please enter a name." else onConfirm(text)
        if (err == null) onDismiss() else error = err
    }
    PdfDialog(title, onDismiss, content = {
        PdfTextField(text, { text = it; error = null }, "Name", Modifier.fillMaxWidth(), isError = error != null, onDone = submit, label = title)
        if (error != null) Text(error!!, style = Type.small, color = Pdfly.colors.error)
    }) {
        PButton("Cancel", onDismiss, style = BtnStyle.Secondary)
        PButton(confirmLabel, submit)
    }
}

// ---------- toast ----------

@Composable
fun ToastHost(toast: ToastMsg?, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    var shown by remember { mutableStateOf<ToastMsg?>(null) }
    if (toast != null) shown = toast
    LaunchedEffect(toast?.id) {
        if (toast != null) {
            delay(3800)
            onDismiss()
        }
    }
    val c = Pdfly.colors
    Box(modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp), contentAlignment = Alignment.BottomCenter) {
        AnimatedVisibility(
            visible = toast != null,
            enter = fadeIn(tween(180)) + slideInVertically(tween(200)) { it / 2 },
            exit = fadeOut(tween(160)) + slideOutVertically(tween(180)) { it / 2 },
        ) {
            val t = shown
            if (t != null) {
                val (icon, tint) = when (t.kind) {
                    ToastKind.SUCCESS -> Icons.Outlined.CheckCircle to c.success
                    ToastKind.ERROR -> Icons.Outlined.ErrorOutline to c.error
                    ToastKind.INFO -> Icons.Outlined.Info to c.info
                }
                Row(
                    Modifier.widthIn(max = 480.dp).clip(Radius.md).background(if (c.dark) c.elevated else Color(0xFF0F172A))
                        .clickable { onDismiss() }.padding(horizontal = 16.dp, vertical = 12.dp)
                        .semantics { liveRegion = LiveRegionMode.Polite },
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp))
                    Text(t.text, style = Type.secondary, color = Color.White, maxLines = 4)
                }
            }
        }
    }
}

// ---------- upload zone ----------

@Composable
fun Dropzone(
    title: String,
    subtitle: String,
    buttonLabel: String,
    onChoose: () -> Unit,
    modifier: Modifier = Modifier,
    secondaryLabel: String? = null,
    onSecondary: (() -> Unit)? = null,
) {
    val c = Pdfly.colors
    val dash = PathEffect.dashPathEffect(floatArrayOf(18f, 14f))
    val col = c.primary
    Column(
        modifier.fillMaxWidth().clip(Radius.xl).background(c.surface)
            .drawBehind {
                drawRoundRect(col, size = Size(size.width, size.height), cornerRadius = CornerRadius(20.dp.toPx()), style = DrawStroke(width = 2.dp.toPx(), pathEffect = dash))
            }
            .clickable(role = Role.Button, onClick = onChoose)
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        IconTile(Icons.Outlined.FileUpload, 56.dp, 28.dp)
        Spacer(Modifier.height(4.dp))
        Text(title, style = Type.cardTitle, color = c.text)
        Text(subtitle, style = Type.secondary, color = c.textSecondary)
        Spacer(Modifier.height(6.dp))
        PButton(buttonLabel, onChoose)
        if (secondaryLabel != null && onSecondary != null) PButton(secondaryLabel, onSecondary, style = BtnStyle.Ghost)
    }
}

// ---------- thumbnails & files ----------

@Composable
fun PdfThumb(item: PdfItem, modifier: Modifier = Modifier, page: Int = 0, widthPx: Int = 320) {
    val c = Pdfly.colors
    val bmp by produceState<Bitmap?>(null, item.path, item.modified, page) {
        value = Thumbs.get(item.file, item.modified, page, widthPx)
    }
    Box(modifier.clip(RoundedCornerShape(8.dp)).background(c.primarySoft).border(1.dp, c.border, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), item.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
        } else {
            Icon(Icons.Outlined.Description, null, tint = c.accentText, modifier = Modifier.size(22.dp))
        }
    }
}

class FileUi(val vm: AppViewModel, val ctx: Context, val onOpen: (PdfItem) -> Unit) {
    var renaming by mutableStateOf<PdfItem?>(null)
    var deleting by mutableStateOf<PdfItem?>(null)

    fun share(item: PdfItem) {
        try {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", item.file)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ctx.startActivity(Intent.createChooser(i, "Share PDF").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Throwable) {
            vm.showToast("Couldn't share this file", ToastKind.ERROR)
        }
    }
}

@Composable
fun rememberFileUi(vm: AppViewModel, onOpen: (PdfItem) -> Unit): FileUi {
    val ctx = LocalContext.current
    return remember(vm, ctx) { FileUi(vm, ctx, onOpen) }.also { }
}

@Composable
fun FileDialogs(ui: FileUi) {
    ui.renaming?.let { item ->
        TextInputDialog("Rename PDF", item.name.removeSuffix(".pdf"), "Rename", onConfirm = { ui.vm.rename(item, it) }, onDismiss = { ui.renaming = null })
    }
    ui.deleting?.let { item ->
        ConfirmDialog(
            "Delete this PDF?",
            "“${item.name}” will be permanently removed from this device. This can't be undone.",
            "Delete",
            onConfirm = { ui.vm.delete(item); ui.deleting = null },
            onDismiss = { ui.deleting = null },
        )
    }
}

@Composable
fun FileMenu(item: PdfItem, ui: FileUi) {
    var open by remember { mutableStateOf(false) }
    val c = Pdfly.colors
    Box {
        IconBtn(Icons.Outlined.MoreVert, "More options for ${item.name}", { open = true })
        DropdownMenu(open, { open = false }, containerColor = c.elevated, shape = Radius.md) {
            @Composable
            fun entry(label: String, icon: ImageVector, tint: Color = c.text, action: () -> Unit) {
                DropdownMenuItem(
                    text = { Text(label, style = Type.body, color = tint) },
                    leadingIcon = { Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp)) },
                    onClick = { open = false; action() },
                )
            }
            entry("Open", Icons.Outlined.Description) { ui.onOpen(item) }
            entry("Rename", Icons.Outlined.DriveFileRenameOutline) { ui.renaming = item }
            entry("Download", Icons.Outlined.FileDownload) { ui.vm.download(item) }
            entry("Share", Icons.Outlined.Share) { ui.share(item) }
            entry("Delete", Icons.Outlined.DeleteOutline, c.error) { ui.deleting = item }
        }
    }
}

@Composable
fun StarButton(item: PdfItem, ui: FileUi) {
    IconBtn(
        if (item.starred) Icons.Outlined.Star else Icons.Outlined.StarBorder,
        if (item.starred) "Remove ${item.name} from starred" else "Add ${item.name} to starred",
        { ui.vm.toggleStar(item) },
        tint = if (item.starred) Pdfly.colors.warning else Pdfly.colors.textMuted,
    )
}

@Composable
fun FileRow(item: PdfItem, ui: FileUi, modifier: Modifier = Modifier) {
    val c = Pdfly.colors
    SurfaceCard(modifier.fillMaxWidth(), onClick = { ui.onOpen(item) }, padding = 10.dp) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PdfThumb(item, Modifier.size(width = 42.dp, height = 56.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(item.name, style = Type.bodyMedium, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(item.meta, style = Type.small, color = c.textSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            StarButton(item, ui)
            FileMenu(item, ui)
        }
    }
}

@Composable
fun FileCard(item: PdfItem, ui: FileUi, modifier: Modifier = Modifier) {
    val c = Pdfly.colors
    SurfaceCard(modifier, onClick = { ui.onOpen(item) }, padding = 10.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            PdfThumb(item, Modifier.fillMaxWidth().height(150.dp), widthPx = 420)
            Text(item.name, style = Type.bodyMedium, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${com.pdfly.app.data.formatSize(item.size)} · ${item.pagesLabel}", style = Type.small, color = c.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(com.pdfly.app.data.formatDate(item.modified), style = Type.small, color = c.textMuted, maxLines = 1)
                }
                StarButton(item, ui)
                FileMenu(item, ui)
            }
        }
    }
}
