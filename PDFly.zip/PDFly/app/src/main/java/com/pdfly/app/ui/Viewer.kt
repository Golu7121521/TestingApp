package com.pdfly.app.ui

import android.content.Context
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.FitScreen
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Print
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material.icons.outlined.ViewSidebar
import androidx.compose.material.icons.outlined.ZoomIn
import androidx.compose.material.icons.outlined.ZoomOut
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.pdfly.app.data.AppViewModel
import com.pdfly.app.data.PdfItem
import com.pdfly.app.data.PdfSession
import com.pdfly.app.data.Thumbs
import com.pdfly.app.data.ToastKind
import com.pdfly.app.data.friendlyError
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.math.roundToInt

private class FilePrintAdapter(private val file: File, private val name: String) : PrintDocumentAdapter() {
    override fun onLayout(
        old: PrintAttributes?, new: PrintAttributes?, signal: CancellationSignal?,
        callback: LayoutResultCallback, extras: Bundle?,
    ) {
        if (signal?.isCanceled == true) { callback.onLayoutCancelled(); return }
        val info = PrintDocumentInfo.Builder(name)
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
            .build()
        callback.onLayoutFinished(info, true)
    }

    override fun onWrite(pages: Array<out PageRange>?, dest: ParcelFileDescriptor, signal: CancellationSignal?, callback: WriteResultCallback) {
        try {
            FileInputStream(file).use { i -> FileOutputStream(dest.fileDescriptor).use { o -> i.copyTo(o) } }
            callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
        } catch (e: Throwable) {
            callback.onWriteFailed(e.message)
        }
    }
}

@Composable
fun ViewerScreen(vm: AppViewModel, name: String, onBack: () -> Unit, ui: FileUi) {
    val c = Pdfly.colors
    val ctx = LocalContext.current
    val item = vm.items.firstOrNull { it.name == name }
    if (item == null) {
        Box(Modifier.fillMaxSize().statusBarsPadding(), contentAlignment = Alignment.Center) {
            if (vm.loading) ProgressBlock("Opening…", null)
            else ErrorState("This file is no longer in your library.", null, onBack)
        }
        return
    }

    var attempt by remember { mutableIntStateOf(0) }
    var session by remember { mutableStateOf<PdfSession?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(item.path, attempt) {
        session = null
        error = null
        try {
            session = PdfSession.open(item.file)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            error = friendlyError(e)
        }
    }
    DisposableEffect(session) { val s = session; onDispose { s?.close() } }

    var zoom by remember { mutableFloatStateOf(1f) }
    var thumbs by remember { mutableStateOf(vm.thumbsDefault) }
    var showSearchInfo by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val current by remember { derivedStateOf { listState.firstVisibleItemIndex } }
    var pageText by remember { mutableStateOf("1") }
    LaunchedEffect(current) { pageText = (current + 1).toString() }

    Column(Modifier.fillMaxSize().background(c.canvas).statusBarsPadding()) {
        // ---- toolbar ----
        Column(Modifier.fillMaxWidth().background(c.surface)) {
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBtn(Icons.AutoMirrored.Filled.ArrowBack, "Back", onBack, tint = c.text)
                Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
                    Text(item.name, style = Type.cardTitle, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("Read-only · ${com.pdfly.app.data.formatSize(item.size)}", style = Type.small, color = c.textMuted, maxLines = 1)
                }
                Box {
                    IconBtn(Icons.Outlined.MoreVert, "More options", { menu = true })
                    DropdownMenu(menu, { menu = false }, containerColor = c.elevated, shape = Radius.md) {
                        @Composable
                        fun entry(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color = c.text, act: () -> Unit) =
                            DropdownMenuItem(
                                text = { Text(label, style = Type.body, color = tint) },
                                leadingIcon = { Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp)) },
                                onClick = { menu = false; act() },
                            )
                        entry("Rename", Icons.Outlined.DriveFileRenameOutline) { ui.renaming = item }
                        entry("Share", Icons.Outlined.Share) { ui.share(item) }
                        entry("Delete", Icons.Outlined.DeleteOutline, c.error) { ui.deleting = item }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                val total = session?.pageCount ?: item.pages.coerceAtLeast(0)
                IconBtn(Icons.Outlined.ViewSidebar, if (thumbs) "Hide thumbnails" else "Show thumbnails", { thumbs = !thumbs }, tint = if (thumbs) c.accentText else c.textSecondary)
                Sep()
                IconBtn(Icons.Outlined.ChevronLeft, "Previous page", { scope.launch { listState.animateScrollToItem((current - 1).coerceAtLeast(0)) } }, enabled = current > 0)
                PdfTextField(
                    pageText, { v -> pageText = v.filter { it.isDigit() }.take(5) }, "1", Modifier.width(76.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Go),
                    onDone = {
                        val n = pageText.toIntOrNull()
                        if (n != null && total > 0) scope.launch { listState.scrollToItem((n - 1).coerceIn(0, total - 1)) }
                    },
                    label = "Page number",
                )
                Text("/ $total", style = Type.secondary, color = c.textSecondary, modifier = Modifier.padding(horizontal = 6.dp))
                IconBtn(Icons.Outlined.ChevronRight, "Next page", { scope.launch { listState.animateScrollToItem((current + 1).coerceAtMost((total - 1).coerceAtLeast(0))) } }, enabled = current < total - 1)
                Sep()
                IconBtn(Icons.Outlined.ZoomOut, "Zoom out", { zoom = (zoom / 1.25f).coerceAtLeast(0.5f) }, enabled = zoom > 0.5f)
                Text("${(zoom * 100).roundToInt()}%", style = Type.secondary, color = c.text, modifier = Modifier.width(48.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                IconBtn(Icons.Outlined.ZoomIn, "Zoom in", { zoom = (zoom * 1.25f).coerceAtMost(4f) }, enabled = zoom < 4f)
                IconBtn(Icons.Outlined.SwapHoriz, "Fit to width", { zoom = 1f })
                FitPageButton(session, current, onZoom = { zoom = it }, getViewport = { viewport })
                Sep()
                IconBtn(Icons.Outlined.Search, "Search in document", { showSearchInfo = true })
                IconBtn(Icons.Outlined.FileDownload, "Download", { vm.download(item) })
                IconBtn(Icons.Outlined.Print, "Print", {
                    try {
                        val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
                        pm.print(item.name, FilePrintAdapter(item.file, item.name), null)
                    } catch (e: Throwable) {
                        vm.showToast("Couldn't start printing", ToastKind.ERROR)
                    }
                })
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(c.border))
        }

        // ---- body ----
        val s = session
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val wide = maxWidth >= 840.dp
            viewport = maxWidth to maxHeight
            when {
                error != null -> ErrorState(error!!, { attempt++ }, onBack)
                s == null -> Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Skeleton(Modifier.fillMaxWidth().aspectRatio(0.707f))
                    Spacer(Modifier.height(12.dp))
                    ProgressBlock("Opening ${item.name}…", null)
                }
                else -> {
                    val thumbList: @Composable (Boolean) -> Unit = { vertical ->
                        ThumbPanel(item, s, current, vertical) { i -> scope.launch { listState.scrollToItem(i) } }
                    }
                    if (wide) {
                        Row(Modifier.fillMaxSize()) {
                            if (thumbs) {
                                Box(Modifier.width(148.dp).fillMaxHeight().background(c.surface)) { thumbList(true) }
                                Box(Modifier.width(1.dp).fillMaxHeight().background(c.border))
                            }
                            PagesList(s, listState, zoom, Modifier.weight(1f).fillMaxHeight())
                        }
                    } else {
                        Column(Modifier.fillMaxSize()) {
                            PagesList(s, listState, zoom, Modifier.weight(1f).fillMaxWidth())
                            if (thumbs) {
                                Box(Modifier.fillMaxWidth().height(96.dp).background(c.surface).navigationBarsPadding()) { thumbList(false) }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSearchInfo) {
        PdfDialog(
            "Search in document", { showSearchInfo = false },
            description = "Searching inside a PDF isn't available yet. Android's built-in PDF renderer shows pages but doesn't let apps read their text. You can still search for files by name from the main search.",
        ) { PButton("Got it", { showSearchInfo = false }) }
    }
}

private var viewport: Pair<androidx.compose.ui.unit.Dp, androidx.compose.ui.unit.Dp> =
    360.dp to 640.dp

@Composable
private fun Sep() {
    Box(Modifier.padding(horizontal = 6.dp).width(1.dp).height(24.dp).background(Pdfly.colors.border))
}

@Composable
private fun FitPageButton(session: PdfSession?, page: Int, onZoom: (Float) -> Unit, getViewport: () -> Pair<androidx.compose.ui.unit.Dp, androidx.compose.ui.unit.Dp>) {
    IconBtn(Icons.Outlined.FitScreen, "Fit to page", {
        val sz = session?.sizes?.getOrNull(page)
        if (sz != null) {
            val (vw, vh) = getViewport()
            val availW = vw.value - 32f
            val availH = vh.value - 32f
            val pageHAtFullWidth = availW * sz.second / sz.first
            onZoom((availH / pageHAtFullWidth).coerceIn(0.5f, 1f))
        }
    })
}

@Composable
private fun PagesList(session: PdfSession, state: androidx.compose.foundation.lazy.LazyListState, zoom: Float, modifier: Modifier) {
    val c = Pdfly.colors
    BoxWithConstraints(modifier) {
        val containerW = maxWidth
        val pageW = ((containerW - 32.dp) * zoom).coerceAtLeast(120.dp)
        val totalW = (pageW + 32.dp).coerceAtLeast(containerW)
        Box(Modifier.fillMaxSize().horizontalScroll(rememberScrollState())) {
            LazyColumn(
                state = state,
                modifier = Modifier.width(totalW).fillMaxHeight(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                items(session.pageCount, key = { it }) { i ->
                    val (pw, ph) = session.sizes[i]
                    val density = LocalDensity.current
                    val px = with(density) { pageW.roundToPx() }.coerceIn(200, 2000)
                    val bmp by produceState<android.graphics.Bitmap?>(null, i, px) {
                        value = try { session.render(i, px) } catch (e: CancellationException) { throw e } catch (e: Throwable) { null }
                    }
                    Box(
                        Modifier.width(pageW).aspectRatio(pw.toFloat() / ph).shadow(3.dp, RoundedCornerShape(2.dp)).background(Color.White),
                        contentAlignment = Alignment.Center,
                    ) {
                        val b = bmp
                        if (b != null) Image(b.asImageBitmap(), "Page ${i + 1}", Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                        else Skeleton(Modifier.fillMaxSize(), RoundedCornerShape(0.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ThumbPanel(item: PdfItem, session: PdfSession, current: Int, vertical: Boolean, onPick: (Int) -> Unit) {
    val c = Pdfly.colors
    val cell: @Composable (Int) -> Unit = { i ->
        val selected = i == current
        val (pw, ph) = session.sizes[i]
        val bmp by produceState<android.graphics.Bitmap?>(null, i) { value = Thumbs.get(item.file, item.modified, i, 260) }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Box(
                Modifier.then(if (vertical) Modifier.width(96.dp) else Modifier.height(58.dp))
                    .aspectRatio(pw.toFloat() / ph)
                    .clip(RoundedCornerShape(6.dp)).background(Color.White)
                    .border(if (selected) 2.dp else 1.dp, if (selected) c.primary else c.border, RoundedCornerShape(6.dp))
                    .clickable(role = androidx.compose.ui.semantics.Role.Button) { onPick(i) },
            ) {
                val b = bmp
                if (b != null) Image(b.asImageBitmap(), "Go to page ${i + 1}", Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
            }
            Text("${i + 1}", style = Type.small, color = if (selected) c.accentText else c.textMuted)
        }
    }
    val listState = rememberLazyListState()
    LaunchedEffect(current) { if (current in 0 until session.pageCount) listState.animateScrollToItem(current) }
    if (vertical) {
        LazyColumn(state = listState, modifier = Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            items(session.pageCount) { cell(it) }
        }
    } else {
        LazyRow(state = listState, modifier = Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            items(session.pageCount) { cell(it) }
        }
    }
}
