package com.pdfly.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Compress
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.FileUpload
import androidx.compose.material.icons.outlined.FormatListBulleted
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.MergeType
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material.icons.outlined.Sync
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pdfly.app.data.AppViewModel
import com.pdfly.app.data.SortBy
import com.pdfly.app.data.ThemeMode
import java.util.Calendar

@Composable
fun ScreenScaffold(wide: Boolean, content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier.fillMaxSize().widthIn(max = 1100.dp).verticalScroll(rememberScrollState())
                .padding(horizontal = if (wide) 32.dp else 16.dp, vertical = if (wide) 28.dp else 20.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(24.dp),
        ) { content() }
    }
}

private class QuickAction(val dest: Dest, val icon: ImageVector, val desc: String)

private val quickActions = listOf(
    QuickAction(Dest.MERGE, Icons.Outlined.MergeType, "Combine multiple PDFs into one file."),
    QuickAction(Dest.SPLIT, Icons.Outlined.ContentCut, "Extract pages from a PDF."),
    QuickAction(Dest.COMPRESS, Icons.Outlined.Compress, "Reduce PDF file size."),
    QuickAction(Dest.CONVERT, Icons.Outlined.Sync, "Turn images into a PDF, or PDF pages into images."),
    QuickAction(Dest.EDIT, Icons.Outlined.Edit, "Draw and highlight on your PDF pages."),
    QuickAction(Dest.ORGANIZE, Icons.Outlined.Layers, "Reorder, rotate, or remove pages."),
)

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        h < 12 -> "Good morning"
        h < 17 -> "Good afternoon"
        else -> "Good evening"
    }
}

@Composable
fun HomeScreen(vm: AppViewModel, ui: FileUi, wide: Boolean, nav: (Dest) -> Unit, upload: () -> Unit) {
    val c = Pdfly.colors
    ScreenScaffold(wide) {
        PageHeader(greeting(), "Manage, organize, and work with your PDFs in one place.") {
            PButton("Upload PDF", upload, icon = Icons.Outlined.FileUpload)
        }
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Heading("Quick Actions")
            BoxWithConstraints {
                val cols = when {
                    maxWidth >= 760.dp -> 3
                    maxWidth >= 480.dp -> 2
                    else -> 1
                }
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    quickActions.chunked(cols).forEach { rowItems ->
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            rowItems.forEach { qa ->
                                SurfaceCard(Modifier.weight(1f).height(112.dp), onClick = { nav(qa.dest) }) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
                                        IconTile(qa.icon)
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text(qa.dest.label, style = Type.cardTitle, color = c.text)
                                            Text(qa.desc, style = Type.secondary, color = c.textSecondary, maxLines = 3)
                                        }
                                    }
                                }
                            }
                            repeat(cols - rowItems.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) { Heading("Recent Files") }
                if (vm.items.isNotEmpty()) PButton("View All", { nav(Dest.ALL) }, style = BtnStyle.Ghost)
            }
            when {
                vm.loading -> SkeletonList(3)
                vm.loadError != null -> ErrorState(vm.loadError!!, vm::refresh, null)
                vm.items.isEmpty() -> SurfaceCard(Modifier.fillMaxWidth()) {
                    EmptyState(
                        Icons.Outlined.Folder, "Your workspace is ready.", "Upload your first PDF to get started.",
                        primaryLabel = "Upload PDF", onPrimary = upload,
                        secondaryLabel = "Explore PDF tools", onSecondary = { nav(Dest.MERGE) },
                    )
                }
                else -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    vm.sorted(vm.items, SortBy.MODIFIED).take(5).forEach { FileRow(it, ui) }
                }
            }
        }
    }
}

@Composable
fun LibraryScreen(kind: Dest, vm: AppViewModel, ui: FileUi, wide: Boolean, upload: () -> Unit) {
    val c = Pdfly.colors
    var q by rememberSaveable { mutableStateOf("") }
    var sortMenu by remember { mutableStateOf(false) }
    val query = q.trim().lowercase()

    val base = when (kind) {
        Dest.STARRED -> vm.items.filter { it.starred }
        Dest.SHARED -> vm.items.filter { it.shared }
        else -> vm.items
    }
    val filtered = base.filter { query.isEmpty() || it.name.lowercase().contains(query) }
    val list = if (kind == Dest.RECENT) vm.sorted(filtered, SortBy.MODIFIED).take(30) else vm.sorted(filtered)

    val (title, subtitle) = when (kind) {
        Dest.RECENT -> "Recent Files" to "Pick up where you left off."
        Dest.STARRED -> "Starred" to "Your favourite documents."
        Dest.SHARED -> "Shared Files" to "PDFs you opened or received from other apps."
        else -> "All PDFs" to "Manage all your documents in one place."
    }

    val pad = if (wide) 32.dp else 16.dp
    Column(Modifier.fillMaxSize().padding(top = if (wide) 28.dp else 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(Modifier.padding(horizontal = pad), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            PageHeader(title, subtitle) { PButton("Upload PDF", upload, icon = Icons.Outlined.FileUpload) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                PdfTextField(q, { q = it }, "Search PDFs", Modifier.weight(1f), leading = Icons.Outlined.Search, label = "Search in this list")
                if (kind != Dest.RECENT) {
                    Box {
                        Row(
                            Modifier.height(46.dp).clip(Radius.md).background(c.surface).border(1.dp, c.border, Radius.md)
                                .clickable(role = Role.Button) { sortMenu = true }
                                .semantics { contentDescription = "Sort by ${vm.sortBy.label}" }
                                .padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            if (wide) Text(vm.sortBy.label, style = Type.secondary, color = c.text)
                            Icon(Icons.Outlined.ExpandMore, null, tint = c.textSecondary, modifier = Modifier.size(18.dp))
                        }
                        DropdownMenu(sortMenu, { sortMenu = false }, containerColor = c.elevated, shape = Radius.md) {
                            SortBy.values().forEach { s ->
                                DropdownMenuItem(
                                    text = { Text(s.label, style = Type.body, color = if (s == vm.sortBy) c.accentText else c.text, fontWeight = if (s == vm.sortBy) FontWeight.SemiBold else FontWeight.Normal) },
                                    onClick = { vm.updateSort(s); sortMenu = false },
                                )
                            }
                        }
                    }
                }
                IconBtn(
                    if (vm.gridView) Icons.Outlined.FormatListBulleted else Icons.Outlined.GridView,
                    if (vm.gridView) "Switch to list view" else "Switch to grid view",
                    { vm.updateGrid(!vm.gridView) },
                    background = c.surface, size = 46.dp,
                )
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                vm.loading -> Column(Modifier.padding(horizontal = pad)) { SkeletonList(5) }
                vm.loadError != null -> ErrorState(vm.loadError!!, vm::refresh, null)
                base.isEmpty() -> {
                    val (icon, t, d) = when (kind) {
                        Dest.STARRED -> Triple(Icons.Outlined.StarOutline, "No starred PDFs", "Tap the star on a file to keep it here.")
                        Dest.SHARED -> Triple(Icons.Outlined.People, "Nothing shared yet", "PDFs you open from other apps (Files, WhatsApp, Gmail…) will appear here.")
                        else -> Triple(Icons.Outlined.Folder, "Your workspace is ready.", "Upload your first PDF to get started.")
                    }
                    EmptyState(icon, t, d, primaryLabel = if (kind == Dest.STARRED || kind == Dest.SHARED) null else "Upload PDF", onPrimary = upload)
                }
                list.isEmpty() -> EmptyState(Icons.Outlined.Search, "No results found", "Nothing matches “$q”. Try a different name.", primaryLabel = "Clear search", onPrimary = { q = "" })
                vm.gridView -> LazyVerticalGrid(
                    GridCells.Adaptive(if (wide) 200.dp else 160.dp),
                    contentPadding = PaddingValues(start = pad, end = pad, bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) { items(list, key = { it.path }) { FileCard(it, ui) } }
                else -> LazyColumn(
                    contentPadding = PaddingValues(start = pad, end = pad, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) { items(list, key = { it.path }) { FileRow(it, ui) } }
            }
        }
    }
}

// ---------- settings ----------

@Composable
private fun SettingsSection(title: String, content: @Composable () -> Unit) {
    val c = Pdfly.colors
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, style = Type.cardTitle, color = c.text)
        SurfaceCard(Modifier.fillMaxWidth()) { Column(verticalArrangement = Arrangement.spacedBy(14.dp)) { content() } }
    }
}

@Composable
private fun ToggleRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = Pdfly.colors
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f)) {
            Text(title, style = Type.bodyMedium, color = c.text)
            Text(desc, style = Type.small, color = c.textSecondary)
        }
        Switch(
            checked, onChange,
            colors = SwitchDefaults.colors(checkedThumbColor = c.onPrimary, checkedTrackColor = c.primary, uncheckedTrackColor = c.border, uncheckedThumbColor = c.surface, uncheckedBorderColor = c.border),
        )
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel, wide: Boolean) {
    val c = Pdfly.colors
    var confirmDelete by remember { mutableStateOf(false) }
    ScreenScaffold(wide) {
        PageHeader("Settings", "Make PDFly work the way you like.")
        SettingsSection("Appearance") {
            Text("Theme", style = Type.bodyMedium, color = c.text)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.values().forEach { m -> Chip(m.label, vm.themeMode == m) { vm.updateTheme(m) } }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.size(22.dp).clip(androidx.compose.foundation.shape.CircleShape).background(c.primary))
                Column {
                    Text("Accent colour", style = Type.bodyMedium, color = c.text)
                    Text("Light Blue (default)", style = Type.small, color = c.textSecondary)
                }
            }
        }
        SettingsSection("PDF Viewer") {
            ToggleRow("Fit whole page on open", "Off: pages fit the screen width.", vm.defaultFitPage, vm::updateFitPage)
            ToggleRow("Show page thumbnails", "Show the page strip when you open a PDF.", vm.thumbsDefault, vm::updateThumbs)
        }
        SettingsSection("File Management") {
            Text("Default sort order", style = Type.bodyMedium, color = c.text)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SortBy.values().toList().chunked(2).forEach { r ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { r.forEach { s -> Chip(s.label, vm.sortBy == s) { vm.updateSort(s) } } }
                }
            }
            Text("Library layout", style = Type.bodyMedium, color = c.text)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("List", !vm.gridView) { vm.updateGrid(false) }
                Chip("Grid", vm.gridView) { vm.updateGrid(true) }
            }
        }
        SettingsSection("Privacy") {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconTile(Icons.Outlined.Shield)
                Text(
                    "Your PDFs are copied into PDFly's private storage on this device and processed here. " +
                        "PDFly has no internet permission, so nothing is uploaded anywhere. " +
                        "Files you save go to Downloads/PDFly (or Pictures/PDFly for images) and stay there until you delete them. " +
                        "Uninstalling PDFly removes its private library.",
                    style = Type.secondary, color = c.textSecondary,
                )
            }
            PButton("Delete all PDFs from PDFly", { confirmDelete = true }, style = BtnStyle.Secondary, icon = Icons.Outlined.DeleteOutline, enabled = vm.items.isNotEmpty())
        }
        SettingsSection("About") {
            Text("PDFly 1.0 · PDF pages are rendered with Google's Android PdfRenderer.", style = Type.secondary, color = c.textSecondary)
        }
    }
    if (confirmDelete) {
        ConfirmDialog(
            "Delete all PDFs?", "All ${vm.items.size} PDFs in PDFly will be permanently removed from this device. Copies you saved to Downloads are not affected.",
            "Delete all", { vm.deleteAll(); confirmDelete = false }, { confirmDelete = false },
        )
    }
}

@Composable
fun HelpScreen(wide: Boolean) {
    val c = Pdfly.colors
    val faqs = listOf(
        "How do I add a PDF?" to "Tap “New PDF” or “Upload PDF” and pick files from your phone. You can also open a PDF from any app using “Open with PDFly” or Share.",
        "Where are my files stored?" to "In PDFly's private storage on your phone. Use Download in a file's menu to save a copy to Downloads/PDFly.",
        "Are merged, split and edited PDFs searchable?" to "No. Android's built-in PDF renderer can display pages but not copy their text, so PDFly rebuilds output PDFs from page images. Text becomes non-selectable and results can be larger than the source. Compress is best on scanned or image-heavy files.",
        "Can I search inside a PDF?" to "Not yet. Search looks at file names and details only, because Android's renderer doesn't expose page text.",
        "Does Sign PDF create a legally binding signature?" to "No. It places an image of your signature on the page. It is not a certified digital signature.",
        "Can I open password-protected PDFs?" to "Not at the moment. Remove the password in another app first.",
        "Which conversions are supported?" to "Images → PDF and PDF → PNG/JPG. Word, Excel and PowerPoint conversion are not available.",
    )
    ScreenScaffold(wide) {
        PageHeader("Help & Support", "Answers to common questions and the app's honest limits.")
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            faqs.forEach { (q, a) ->
                var open by remember { mutableStateOf(false) }
                SurfaceCard(Modifier.fillMaxWidth(), onClick = { open = !open }) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(q, style = Type.cardTitle, color = c.text, modifier = Modifier.weight(1f))
                            Icon(Icons.Outlined.ExpandMore, null, tint = c.textSecondary)
                        }
                        if (open) Text(a, style = Type.body, color = c.textSecondary)
                    }
                }
            }
        }
    }
}
