package com.pdfly.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.DragHandle
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.RotateRight
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.pdfly.app.data.AppViewModel
import com.pdfly.app.data.PageSpec
import com.pdfly.app.data.PdfItem
import com.pdfly.app.data.PdfOps
import com.pdfly.app.data.PdfSession
import com.pdfly.app.data.Thumbs
import com.pdfly.app.data.ToastKind
import com.pdfly.app.data.formatSize
import com.pdfly.app.data.friendlyError
import com.pdfly.app.data.parsePageRanges
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.roundToInt

// ------------------------------------------------------------------ shared tool plumbing

/** Runs one long operation and exposes progress / result / error to the UI. */
@Stable
class Runner(private val scope: CoroutineScope) {
    var running by mutableStateOf(false)
    var progress by mutableStateOf<Float?>(null)
    var label by mutableStateOf("")
    var error by mutableStateOf<String?>(null)
    var warning by mutableStateOf<String?>(null)
    var note by mutableStateOf<String?>(null)
    var results by mutableStateOf<List<PdfItem>>(emptyList())
    private var job: Job? = null

    fun reset() { error = null; warning = null; note = null; results = emptyList(); progress = null }

    fun start(label: String, block: suspend Runner.() -> Unit) {
        if (running) return
        reset()
        this.label = label
        running = true
        progress = null
        job = scope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                note = "Cancelled. Nothing was saved."
                throw e
            } catch (e: Throwable) {
                error = friendlyError(e)
            } finally {
                running = false
            }
        }
    }

    fun cancel() { job?.cancel() }
}

@Composable
fun rememberRunner(): Runner {
    val scope = rememberCoroutineScope()
    val r = remember { Runner(scope) }
    DisposableEffect(Unit) { onDispose { r.cancel() } }
    return r
}

@Composable
fun RunnerPanel(r: Runner, vm: AppViewModel, open: (PdfItem) -> Unit) {
    val c = Pdfly.colors
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (r.running) {
            SurfaceCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ProgressBlock(r.label, r.progress)
                    PButton("Cancel", { r.cancel() }, style = BtnStyle.Secondary)
                }
            }
        }
        r.error?.let { StatusRow(Icons.Outlined.ErrorOutline, it, c.error) }
        r.warning?.let { StatusRow(Icons.Outlined.Info, it, c.warning) }
        if (r.results.isNotEmpty() && !r.running) {
            StatusRow(Icons.Outlined.CheckCircle, r.note ?: "Done. Your file is in your library.", c.success)
            r.results.take(8).forEach { item ->
                SurfaceCard(Modifier.fillMaxWidth(), padding = 12.dp) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            PdfThumb(item, Modifier.size(width = 40.dp, height = 54.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.name, style = Type.bodyMedium, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${formatSize(item.size)} · ${item.pagesLabel}", style = Type.small, color = c.textSecondary)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PButton("Open", { open(item) })
                            PButton("Download", { vm.download(item) }, style = BtnStyle.Secondary, icon = Icons.Outlined.FileDownload)
                        }
                    }
                }
            }
            if (r.results.size > 8) Text("…and ${r.results.size - 8} more in All PDFs.", style = Type.secondary, color = c.textSecondary)
        } else if (r.note != null && !r.running && r.results.isEmpty()) {
            StatusRow(Icons.Outlined.Info, r.note!!, c.info)
        }
    }
}

@Composable
fun ToolScaffold(wide: Boolean, title: String, subtitle: String, content: @Composable () -> Unit) {
    ScreenScaffold(wide) {
        PageHeader(title, subtitle)
        content()
    }
}

@Composable
fun PickPdfZone(vm: AppViewModel, multiple: Boolean, onPicked: (List<PdfItem>) -> Unit) {
    val scope = rememberCoroutineScope()
    var showLib by remember { mutableStateOf(false) }
    val multi = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch { onPicked(vm.importUris(uris)) }
    }
    val single = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { onPicked(vm.importUris(listOf(uri))) }
    }
    Dropzone(
        title = if (multiple) "Select your PDFs" else "Select your PDF",
        subtitle = "Tap to choose a file from your device",
        buttonLabel = if (multiple) "Choose PDFs" else "Choose PDF",
        onChoose = { if (multiple) multi.launch(arrayOf("application/pdf")) else single.launch(arrayOf("application/pdf")) },
        secondaryLabel = if (vm.items.isNotEmpty()) "Pick from my library" else null,
        onSecondary = { showLib = true },
    )
    if (showLib) LibraryPicker(vm, multiple, { showLib = false }) { onPicked(it) }
}

@Composable
private fun LibraryPicker(vm: AppViewModel, multiple: Boolean, onDismiss: () -> Unit, onPicked: (List<PdfItem>) -> Unit) {
    val c = Pdfly.colors
    val chosen = remember { mutableStateListOf<String>() }
    PdfDialog("Pick from library", onDismiss, content = {
        LazyColumn(Modifier.heightIn(max = 340.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.sorted(vm.items), key = { it.path }) { item ->
                val on = item.path in chosen
                Row(
                    Modifier.fillMaxWidth().clip(Radius.md).border(1.dp, if (on) c.primary else c.border, Radius.md)
                        .background(if (on) c.primarySoft else Color.Transparent)
                        .clickable {
                            if (!multiple) { onPicked(listOf(item)); onDismiss() }
                            else if (on) chosen.remove(item.path) else chosen.add(item.path)
                        }.padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    PdfThumb(item, Modifier.size(width = 34.dp, height = 46.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.name, style = Type.bodyMedium, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${formatSize(item.size)} · ${item.pagesLabel}", style = Type.small, color = c.textSecondary)
                    }
                    if (on) Icon(Icons.Outlined.CheckCircle, "Selected", tint = c.primary)
                }
            }
        }
    }) {
        PButton("Cancel", onDismiss, style = BtnStyle.Secondary)
        if (multiple) PButton("Add ${chosen.size}", {
            onPicked(vm.items.filter { it.path in chosen })
            onDismiss()
        }, enabled = chosen.isNotEmpty())
    }
}

@Composable
fun SelectedFileCard(item: PdfItem, onRemove: () -> Unit, removeLabel: String = "Remove file") {
    val c = Pdfly.colors
    SurfaceCard(Modifier.fillMaxWidth(), padding = 12.dp) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            PdfThumb(item, Modifier.size(width = 44.dp, height = 58.dp))
            Column(Modifier.weight(1f)) {
                Text(item.name, style = Type.bodyMedium, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${formatSize(item.size)} · ${item.pagesLabel}", style = Type.small, color = c.textSecondary)
            }
            IconBtn(Icons.Outlined.Close, removeLabel, onRemove)
        }
    }
}

@Composable
private fun Note(text: String) {
    Text(text, style = Type.secondary, color = Pdfly.colors.textSecondary)
}

@Composable
fun rememberPdfSession(file: File?): Pair<PdfSession?, String?> {
    var session by remember(file?.absolutePath) { mutableStateOf<PdfSession?>(null) }
    var error by remember(file?.absolutePath) { mutableStateOf<String?>(null) }
    LaunchedEffect(file?.absolutePath) {
        session = null; error = null
        if (file != null) {
            try { session = PdfSession.open(file) }
            catch (e: CancellationException) { throw e }
            catch (e: Throwable) { error = friendlyError(e) }
        }
    }
    DisposableEffect(session) { val s = session; onDispose { s?.close() } }
    return session to error
}

private suspend fun pagesOf(item: PdfItem): Int = if (item.pages > 0) item.pages else PdfOps.pageCount(item.file)

// ------------------------------------------------------------------ router

@Composable
fun ToolScreen(dest: Dest, vm: AppViewModel, wide: Boolean, open: (PdfItem) -> Unit, nav: (Dest) -> Unit) {
    when (dest) {
        Dest.MERGE -> MergeTool(vm, wide, open)
        Dest.SPLIT -> SplitTool(vm, wide, open)
        Dest.COMPRESS -> CompressTool(vm, wide, open)
        Dest.CONVERT -> ConvertTool(vm, wide, open)
        Dest.EDIT -> EditTool(vm, open)
        Dest.SIGN -> SignTool(vm, open)
        Dest.ORGANIZE -> OrganizeTool(vm, open)
        else -> {}
    }
}

// ------------------------------------------------------------------ MERGE

@Composable
fun <T> ReorderColumn(
    items: List<T>,
    rowHeight: Dp,
    keyOf: (T) -> Any,
    onMove: (from: Int, to: Int) -> Unit,
    row: @Composable (index: Int, item: T, handle: Modifier) -> Unit,
) {
    val rowPx = with(LocalDensity.current) { rowHeight.toPx() }
    var dragKey by remember { mutableStateOf<Any?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    val itemsNow by rememberUpdatedState(items)
    val onMoveNow by rememberUpdatedState(onMove)

    Column {
        items.forEachIndexed { index, item ->
            val k = keyOf(item)
            androidx.compose.runtime.key(k) {
                val dragging = dragKey == k
                val handle = Modifier.pointerInput(k) {
                    detectDragGestures(
                        onDragStart = { dragKey = k; dragOffset = 0f },
                        onDragEnd = { dragKey = null; dragOffset = 0f },
                        onDragCancel = { dragKey = null; dragOffset = 0f },
                    ) { change, amount ->
                        change.consume()
                        dragOffset += amount.y
                        val cur = itemsNow.indexOfFirst { keyOf(it) == k }
                        if (cur >= 0) {
                            val shift = (dragOffset / rowPx).roundToInt()
                            val target = (cur + shift).coerceIn(0, itemsNow.size - 1)
                            if (target != cur) {
                                onMoveNow(cur, target)
                                dragOffset -= (target - cur) * rowPx
                            }
                        }
                    }
                }
                Box(
                    Modifier.fillMaxWidth().height(rowHeight).zIndex(if (dragging) 1f else 0f)
                        .graphicsLayer { translationY = if (dragging) dragOffset else 0f; if (dragging) { scaleX = 1.02f; scaleY = 1.02f } },
                ) { row(index, item, handle) }
            }
        }
    }
}

@Composable
fun MergeTool(vm: AppViewModel, wide: Boolean, open: (PdfItem) -> Unit) {
    val c = Pdfly.colors
    val files = remember { mutableStateListOf<PdfItem>() }
    val runner = rememberRunner()

    ToolScaffold(wide, "Merge PDF", "Combine multiple PDFs into one file.") {
        PickPdfZone(vm, true) { picked -> picked.forEach { p -> if (files.none { it.path == p.path }) files.add(p) } ; runner.reset() }
        if (files.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${files.size} file${if (files.size == 1) "" else "s"} · press and drag ≡ to reorder", style = Type.secondary, color = c.textSecondary)
                ReorderColumn(files, 68.dp, { it.path }, { from, to -> files.add(to, files.removeAt(from)) }) { index, item, handle ->
                    Box(Modifier.padding(vertical = 4.dp)) {
                        SurfaceCard(Modifier.fillMaxWidth(), padding = 8.dp) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(handle.size(40.dp), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Outlined.DragHandle, "Drag to reorder ${item.name}", tint = c.textMuted)
                                }
                                Text("${index + 1}", style = Type.secondary, color = c.accentText)
                                Column(Modifier.weight(1f)) {
                                    Text(item.name, style = Type.bodyMedium, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${formatSize(item.size)} · ${item.pagesLabel}", style = Type.small, color = c.textSecondary)
                                }
                                IconBtn(Icons.Outlined.Close, "Remove ${item.name}", { files.remove(item); runner.reset() }, size = 40.dp)
                            }
                        }
                    }
                }
            }
            Note("PDFly rebuilds the merged file from page images, so text in the result can't be selected or searched.")
            PButton("Merge PDFs", {
                val list = files.toList()
                runner.start("Merging ${list.size} PDFs…") {
                    val specs = ArrayList<PageSpec>()
                    for (f in list) for (i in 0 until pagesOf(f)) specs.add(PageSpec(f.file, i))
                    val out = vm.newOutputFile("Merged")
                    PdfOps.export(out, specs, 2f, 85) { progress = it }
                    val item = vm.registerOutput(out)
                    results = listOf(item)
                    note = "Merged ${specs.size} pages into ${item.name}."
                    vm.showToast("PDFs merged", ToastKind.SUCCESS)
                }
            }, Modifier.fillMaxWidth(), enabled = files.size >= 2 && !runner.running)
            if (files.size < 2) Note("Add at least two PDFs to merge.")
        }
        RunnerPanel(runner, vm, open)
    }
}

// ------------------------------------------------------------------ SPLIT

@Composable
fun SplitTool(vm: AppViewModel, wide: Boolean, open: (PdfItem) -> Unit) {
    val c = Pdfly.colors
    var file by remember { mutableStateOf<PdfItem?>(null) }
    var pages by remember { mutableStateOf(0) }
    var mode by remember { mutableStateOf(0) } // 0 = range, 1 = every page
    var range by remember { mutableStateOf("") }
    var rangeError by remember { mutableStateOf<String?>(null) }
    val runner = rememberRunner()

    LaunchedEffect(file?.path) { pages = file?.let { pagesOf(it) } ?: 0 }

    ToolScaffold(wide, "Split PDF", "Extract pages from a PDF.") {
        val f = file
        if (f == null) {
            PickPdfZone(vm, false) { file = it.firstOrNull(); runner.reset() }
        } else {
            SelectedFileCard(f, { file = null; range = ""; runner.reset() }, "Choose a different file")
            if (pages <= 0) StatusRow(Icons.Outlined.ErrorOutline, "This PDF's pages couldn't be counted.", c.error)
            else {
                Text("$pages page${if (pages == 1) "" else "s"}", style = Type.bodyMedium, color = c.text)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Extract pages", mode == 0) { mode = 0 }
                    Chip("Every page separately", mode == 1) { mode = 1 }
                }
                if (mode == 0) {
                    PdfTextField(range, { range = it; rangeError = null }, "e.g. 1-3, 5, 8-10", Modifier.fillMaxWidth(), isError = rangeError != null, label = "Pages to extract")
                    if (rangeError != null) Text(rangeError!!, style = Type.small, color = c.error)
                } else {
                    Note(if (pages > 100) "This would create $pages files. Choose “Extract pages” instead (limit: 100 files)." else "Creates $pages separate one-page PDFs.")
                }
                Note("Pages are re-created from images, so text in the new file can't be selected.")
                PButton("Split PDF", {
                    runner.start("Splitting…") {
                        val base = f.title
                        if (mode == 0) {
                            val idx = try { parsePageRanges(range, pages) } catch (e: IllegalArgumentException) { rangeError = e.message; return@start }
                            val out = vm.newOutputFile("$base - pages ${range.replace(" ", "")}")
                            PdfOps.export(out, idx.map { PageSpec(f.file, it) }, 2f, 85) { progress = it }
                            val item = vm.registerOutput(out)
                            results = listOf(item)
                            note = "Extracted ${idx.size} page${if (idx.size == 1) "" else "s"}."
                        } else {
                            require(pages <= 100) { "Too many pages to split into separate files." }
                            val made = ArrayList<PdfItem>()
                            for (i in 0 until pages) {
                                val out = vm.newOutputFile("$base - page ${i + 1}")
                                PdfOps.export(out, listOf(PageSpec(f.file, i)), 2f, 85)
                                made.add(vm.registerOutput(out))
                                progress = (i + 1f) / pages
                            }
                            results = made
                            note = "Created ${made.size} PDFs."
                        }
                        vm.showToast("Split complete", ToastKind.SUCCESS)
                    }
                }, Modifier.fillMaxWidth(), enabled = !runner.running && (mode == 1 && pages <= 100 || mode == 0))
            }
        }
        RunnerPanel(runner, vm, open)
    }
}

// ------------------------------------------------------------------ COMPRESS

private class Preset(val label: String, val desc: String, val scale: Float, val quality: Int)

private val presets = listOf(
    Preset("Smaller file", "Lowest quality, biggest savings", 1.0f, 55),
    Preset("Balanced", "Good quality, smaller size", 1.5f, 72),
    Preset("Better quality", "Sharper pages, smaller savings", 2.0f, 86),
)

@Composable
fun CompressTool(vm: AppViewModel, wide: Boolean, open: (PdfItem) -> Unit) {
    val c = Pdfly.colors
    var file by remember { mutableStateOf<PdfItem?>(null) }
    var preset by remember { mutableStateOf(1) }
    val runner = rememberRunner()

    ToolScaffold(wide, "Compress PDF", "Reduce PDF file size.") {
        val f = file
        if (f == null) {
            PickPdfZone(vm, false) { file = it.firstOrNull(); runner.reset() }
        } else {
            SelectedFileCard(f, { file = null; runner.reset() }, "Choose a different file")
            Text("Original size: ${formatSize(f.size)}", style = Type.bodyMedium, color = c.text)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEachIndexed { i, p ->
                    val on = i == preset
                    Row(
                        Modifier.fillMaxWidth().clip(Radius.md).background(if (on) c.primarySoft else c.surface)
                            .border(if (on) 2.dp else 1.dp, if (on) c.primary else c.border, Radius.md)
                            .clickable(role = androidx.compose.ui.semantics.Role.RadioButton) { preset = i }.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(p.label, style = Type.bodyMedium, color = c.text)
                            Text(p.desc, style = Type.small, color = c.textSecondary)
                        }
                        if (on) Icon(Icons.Outlined.CheckCircle, "Selected", tint = c.primary)
                    }
                }
            }
            Note("The final size depends on your document. Pages are re-saved as compressed images, so text can't be selected afterwards. Works best on scans and image-heavy PDFs.")
            PButton("Compress PDF", {
                val p = presets[preset]
                runner.start("Compressing…") {
                    val n = pagesOf(f)
                    val out = vm.newOutputFile("${f.title} (compressed)")
                    PdfOps.export(out, (0 until n).map { PageSpec(f.file, it) }, p.scale, p.quality) { progress = it }
                    val after = out.length()
                    if (after >= f.size) {
                        out.delete()
                        warning = "This file wouldn't get smaller (${formatSize(f.size)} → ${formatSize(after)}), so no new file was created. Try “Smaller file”, or keep the original."
                    } else {
                        val item = vm.registerOutput(out)
                        results = listOf(item)
                        val saved = ((1 - after.toDouble() / f.size) * 100).roundToInt()
                        note = "${formatSize(f.size)} → ${formatSize(after)} ($saved% smaller)."
                        vm.showToast("Compressed to ${formatSize(after)}", ToastKind.SUCCESS)
                    }
                }
            }, Modifier.fillMaxWidth(), enabled = !runner.running)
        }
        RunnerPanel(runner, vm, open)
    }
}

// ------------------------------------------------------------------ CONVERT

@Composable
fun ConvertTool(vm: AppViewModel, wide: Boolean, open: (PdfItem) -> Unit) {
    val c = Pdfly.colors
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var images by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var file by remember { mutableStateOf<PdfItem?>(null) }
    var png by remember { mutableStateOf(true) }
    val runner = rememberRunner()
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) { images = uris; runner.reset() }
    }

    ToolScaffold(wide, "Convert PDF", "Turn images into a PDF, or PDF pages into images.") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Images → PDF", tab == 0) { tab = 0; runner.reset() }
            Chip("PDF → Images", tab == 1) { tab = 1; runner.reset() }
        }
        if (tab == 0) {
            Dropzone(
                "Select your images", "JPG, PNG or WebP. Pages follow the order you pick them in.", "Choose images",
                { imagePicker.launch("image/*") },
            )
            if (images.isNotEmpty()) {
                SurfaceCard(Modifier.fillMaxWidth(), padding = 12.dp) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconTile(Icons.Outlined.Image)
                        Text("${images.size} image${if (images.size == 1) "" else "s"} selected", style = Type.bodyMedium, color = c.text, modifier = Modifier.weight(1f))
                        IconBtn(Icons.Outlined.Close, "Clear selected images", { images = emptyList(); runner.reset() })
                    }
                }
                PButton("Create PDF", {
                    val list = images
                    runner.start("Creating PDF…") {
                        val out = vm.newOutputFile("Images")
                        PdfOps.imagesToPdf(ctx, list, out) { progress = it }
                        val item = vm.registerOutput(out)
                        results = listOf(item)
                        note = "Created a ${list.size}-page PDF."
                        vm.showToast("PDF created", ToastKind.SUCCESS)
                    }
                }, Modifier.fillMaxWidth(), enabled = !runner.running)
            }
        } else {
            val f = file
            if (f == null) PickPdfZone(vm, false) { file = it.firstOrNull(); runner.reset() }
            else {
                SelectedFileCard(f, { file = null; runner.reset() }, "Choose a different file")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("PNG (sharper)", png) { png = true }
                    Chip("JPG (smaller)", !png) { png = false }
                }
                Note("Every page is saved as an image in Pictures/PDFly.")
                PButton("Save images", {
                    runner.start("Saving images…") {
                        val n = PdfOps.pdfToImages(ctx, f.file, png, f.title) { progress = it }
                        note = "Saved $n image${if (n == 1) "" else "s"} to Pictures/PDFly."
                        vm.showToast("Saved $n images", ToastKind.SUCCESS)
                        results = emptyList()
                    }
                }, Modifier.fillMaxWidth(), enabled = !runner.running)
            }
        }
        RunnerPanel(runner, vm, open)
        SurfaceCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Not available", style = Type.cardTitle, color = c.text)
                Text("Word, Excel, PowerPoint and HTML conversion aren't supported in this version.", style = Type.secondary, color = c.textSecondary)
            }
        }
    }
}

// ------------------------------------------------------------------ ORGANIZE

private class PageState(val id: Int, val orig: Int, val rot: Int)

@Composable
fun OrganizeTool(vm: AppViewModel, open: (PdfItem) -> Unit) {
    val c = Pdfly.colors
    var file by remember { mutableStateOf<PdfItem?>(null) }
    val pages = remember { mutableStateListOf<PageState>() }
    var deleteAt by remember { mutableStateOf<Int?>(null) }
    val runner = rememberRunner()
    val scope = rememberCoroutineScope()

    LaunchedEffect(file?.path) {
        pages.clear()
        val f = file ?: return@LaunchedEffect
        val n = pagesOf(f)
        for (i in 0 until n) pages.add(PageState(i, i, 0))
    }

    val f = file
    if (f == null) {
        ToolScaffold(false, "Organize Pages", "Reorder, rotate, or remove pages.") {
            PickPdfZone(vm, false) { file = it.firstOrNull(); runner.reset() }
        }
        return
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Organize Pages", style = Type.section, color = c.text)
            Text("${f.name} · ${pages.size} page${if (pages.size == 1) "" else "s"}. Use the arrows to reorder.", style = Type.secondary, color = c.textSecondary, maxLines = 2)
        }
        LazyVerticalGrid(
            GridCells.Adaptive(130.dp), Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            itemsIndexed(pages, key = { _, p -> p.id }) { idx, p ->
                val bmp by produceState<android.graphics.Bitmap?>(null, p.orig) { value = Thumbs.get(f.file, f.modified, p.orig, 300) }
                SurfaceCard(Modifier.fillMaxWidth(), padding = 8.dp) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.fillMaxWidth().aspectRatio(0.75f).clip(RoundedCornerShape(6.dp)).background(c.canvas), contentAlignment = Alignment.Center) {
                            val b = bmp
                            if (b != null) {
                                val sideways = p.rot % 180 != 0
                                Image(
                                    b.asImageBitmap(), "Page ${p.orig + 1}",
                                    Modifier.fillMaxSize().graphicsLayer { rotationZ = p.rot.toFloat(); if (sideways) { scaleX = 0.75f; scaleY = 0.75f } },
                                    contentScale = ContentScale.Fit,
                                )
                            }
                        }
                        Text("Page ${idx + 1}", style = Type.small, color = c.textSecondary)
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            IconBtn(Icons.Outlined.ChevronLeft, "Move page ${idx + 1} earlier", { if (idx > 0) { pages.add(idx - 1, pages.removeAt(idx)); runner.reset() } }, enabled = idx > 0, size = 34.dp)
                            IconBtn(Icons.Outlined.RotateRight, "Rotate page ${idx + 1}", {
                                pages[idx] = PageState(p.id, p.orig, (p.rot + 90) % 360); runner.reset()
                            }, size = 34.dp)
                            IconBtn(Icons.Outlined.DeleteOutline, "Delete page ${idx + 1}", { deleteAt = idx }, tint = c.error, size = 34.dp)
                            IconBtn(Icons.Outlined.ChevronRight, "Move page ${idx + 1} later", { if (idx < pages.size - 1) { pages.add(idx + 1, pages.removeAt(idx)); runner.reset() } }, enabled = idx < pages.size - 1, size = 34.dp)
                        }
                    }
                }
            }
        }
        Column(Modifier.fillMaxWidth().background(c.surface).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            RunnerPanel(runner, vm, open)
            Text("Saving creates a new PDF from page images (text won't be selectable). Your original stays unchanged.", style = Type.small, color = c.textMuted)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PButton("Change file", { file = null; runner.reset() }, style = BtnStyle.Secondary)
                PButton("Save new PDF", {
                    val snapshot = pages.toList()
                    runner.start("Saving pages…") {
                        require(snapshot.isNotEmpty()) { "Keep at least one page." }
                        val out = vm.newOutputFile("${f.title} (organized)")
                        PdfOps.export(out, snapshot.map { PageSpec(f.file, it.orig, it.rot) }, 2f, 85) { progress = it }
                        val item = vm.registerOutput(out)
                        results = listOf(item)
                        note = "Saved ${snapshot.size} pages."
                        vm.showToast("Pages saved", ToastKind.SUCCESS)
                    }
                }, Modifier.weight(1f), enabled = pages.isNotEmpty() && !runner.running)
            }
        }
    }

    deleteAt?.let { i ->
        ConfirmDialog(
            "Delete page ${i + 1}?", "It will be left out of the new PDF. Your original file isn't changed.", "Delete page",
            onConfirm = { if (i in pages.indices) pages.removeAt(i); deleteAt = null; runner.reset() },
            onDismiss = { deleteAt = null },
        )
    }
}
