package com.pdfly.app.data

import android.app.Application
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val appCtx: Context = app.applicationContext
    private val sp = appCtx.getSharedPreferences("pdfly_prefs", Context.MODE_PRIVATE)

    /** All PDFs live in the app's private storage. */
    val dir: File = File(appCtx.filesDir, "pdfs").also { it.mkdirs() }

    // ---------- settings ----------
    var themeMode by mutableStateOf(
        runCatching { ThemeMode.valueOf(sp.getString("theme", null) ?: "LIGHT") }.getOrDefault(ThemeMode.LIGHT)
    )
        private set
    var defaultFitPage by mutableStateOf(sp.getBoolean("fitPage", false))
        private set
    var thumbsDefault by mutableStateOf(sp.getBoolean("thumbs", true))
        private set
    var sortBy by mutableStateOf(
        runCatching { SortBy.valueOf(sp.getString("sort", null) ?: "MODIFIED") }.getOrDefault(SortBy.MODIFIED)
    )
        private set
    var gridView by mutableStateOf(sp.getBoolean("grid", false))
        private set

    fun updateTheme(m: ThemeMode) { themeMode = m; sp.edit().putString("theme", m.name).apply() }
    fun updateFitPage(v: Boolean) { defaultFitPage = v; sp.edit().putBoolean("fitPage", v).apply() }
    fun updateThumbs(v: Boolean) { thumbsDefault = v; sp.edit().putBoolean("thumbs", v).apply() }
    fun updateSort(s: SortBy) { sortBy = s; sp.edit().putString("sort", s.name).apply() }
    fun updateGrid(v: Boolean) { gridView = v; sp.edit().putBoolean("grid", v).apply() }

    // ---------- library state ----------
    var items by mutableStateOf<List<PdfItem>>(emptyList())
        private set
    var loading by mutableStateOf(true)
        private set
    var loadError by mutableStateOf<String?>(null)
        private set
    var toast by mutableStateOf<ToastMsg?>(null)
    var pendingIncoming by mutableStateOf<Uri?>(null)

    private val pageCache = HashMap<String, Int>()

    init { refresh() }

    fun showToast(text: String, kind: ToastKind = ToastKind.INFO) {
        toast = ToastMsg(System.nanoTime(), text, kind)
    }

    fun dismissToast() { toast = null }

    @Synchronized
    private fun pagesOf(f: File): Int {
        val key = "${f.absolutePath}|${f.length()}|${f.lastModified()}"
        return pageCache.getOrPut(key) {
            try { PdfOps.probePages(f) } catch (e: Throwable) { -1 }
        }
    }

    private fun stringSet(key: String): MutableSet<String> =
        (sp.getStringSet(key, emptySet()) ?: emptySet()).toMutableSet()

    private fun toItem(f: File, starred: Set<String>, shared: Set<String>): PdfItem = PdfItem(
        name = f.name,
        path = f.absolutePath,
        size = f.length(),
        pages = pagesOf(f),
        modified = f.lastModified(),
        created = sp.getLong("c_${f.name}", f.lastModified()),
        starred = f.name in starred,
        shared = f.name in shared,
    )

    private fun loadItems(): List<PdfItem> {
        val starred = stringSet("starred")
        val shared = stringSet("shared")
        return dir.listFiles { f -> f.isFile && f.name.endsWith(".pdf", ignoreCase = true) }
            .orEmpty()
            .map { toItem(it, starred, shared) }
    }

    fun refresh() {
        viewModelScope.launch {
            if (items.isEmpty()) loading = true
            loadError = null
            try {
                items = withContext(Dispatchers.IO) { loadItems() }
            } catch (e: Exception) {
                loadError = "We couldn't load your library."
            } finally {
                loading = false
            }
        }
    }

    // ---------- names ----------
    fun sanitizeName(raw: String): String {
        val cleaned = raw.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim().ifEmpty { "document" }
        return if (cleaned.endsWith(".pdf", ignoreCase = true)) cleaned else "$cleaned.pdf"
    }

    private fun uniqueFile(name: String): File {
        val base = name.removeSuffix(".pdf").removeSuffix(".PDF")
        var f = File(dir, name)
        var i = 2
        while (f.exists()) {
            f = File(dir, "$base ($i).pdf")
            i++
        }
        return f
    }

    /** A new, not-yet-existing file in the library folder. */
    fun newOutputFile(base: String): File = uniqueFile(sanitizeName(base))

    suspend fun registerOutput(file: File): PdfItem = withContext(Dispatchers.IO) {
        sp.edit().putLong("c_${file.name}", System.currentTimeMillis()).apply()
        val fresh = loadItems()
        items = fresh
        fresh.firstOrNull { it.name == file.name } ?: toItem(file, emptySet(), emptySet())
    }

    private fun displayName(uri: Uri): String {
        var n: String? = null
        try {
            appCtx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) n = c.getString(0)
            }
        } catch (_: Exception) {
        }
        val raw = (n ?: uri.lastPathSegment ?: "document.pdf").substringAfterLast('/')
        return sanitizeName(raw)
    }

    // ---------- import ----------
    fun importAsync(uris: List<Uri>, shared: Boolean = false, onDone: (List<PdfItem>) -> Unit = {}) {
        viewModelScope.launch { onDone(importUris(uris, shared)) }
    }

    suspend fun importUris(uris: List<Uri>, shared: Boolean = false): List<PdfItem> {
        val names = ArrayList<String>()
        var added = 0
        var dupes = 0
        val problems = ArrayList<String>()

        withContext(Dispatchers.IO) {
            for (uri in uris) {
                val name = displayName(uri)
                val tmp = File(appCtx.cacheDir, "import_${System.nanoTime()}.pdf")
                try {
                    val input = appCtx.contentResolver.openInputStream(uri)
                    if (input == null) { problems.add("$name (couldn't be opened)"); continue }
                    input.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }

                    val head = tmp.inputStream().use { s ->
                        val buf = ByteArray(1024)
                        val n = s.read(buf)
                        if (n > 0) String(buf, 0, n, Charsets.ISO_8859_1) else ""
                    }
                    if (!head.contains("%PDF-")) { problems.add("$name (not a PDF)"); continue }

                    try {
                        PdfOps.probePages(tmp)
                    } catch (e: SecurityException) {
                        problems.add("$name (password-protected)"); continue
                    } catch (e: Throwable) {
                        problems.add("$name (damaged or unsupported)"); continue
                    }

                    val existing = dir.listFiles()?.firstOrNull { it.name == name && it.length() == tmp.length() }
                    if (existing != null) {
                        dupes++
                        names.add(existing.name)
                        if (shared) markShared(existing.name)
                        continue
                    }
                    val dest = uniqueFile(name)
                    tmp.copyTo(dest, overwrite = false)
                    sp.edit().putLong("c_${dest.name}", System.currentTimeMillis()).apply()
                    if (shared) markShared(dest.name)
                    names.add(dest.name)
                    added++
                } catch (e: Throwable) {
                    problems.add("$name (${friendlyError(e).removeSuffix(".")})")
                } finally {
                    tmp.delete()
                }
            }
            items = loadItems()
        }

        if (problems.isNotEmpty()) {
            showToast("Couldn't add: ${problems.joinToString("; ")}", ToastKind.ERROR)
        } else if (added > 0) {
            val extra = if (dupes > 0) " ($dupes already in your library)" else ""
            showToast("Added $added PDF${if (added == 1) "" else "s"}$extra", ToastKind.SUCCESS)
        } else if (dupes > 0) {
            showToast("Already in your library", ToastKind.INFO)
        }
        return items.filter { it.name in names }
    }

    private fun markShared(name: String) {
        val s = stringSet("shared")
        s.add(name)
        sp.edit().putStringSet("shared", s).apply()
    }

    // ---------- file actions ----------
    fun toggleStar(item: PdfItem) {
        val s = stringSet("starred")
        if (!s.add(item.name)) s.remove(item.name)
        sp.edit().putStringSet("starred", s).apply()
        items = items.map { if (it.name == item.name) it.copy(starred = !it.starred) else it }
    }

    /** Returns an error message, or null on success. */
    fun rename(item: PdfItem, newRaw: String): String? {
        val name = sanitizeName(newRaw)
        if (name == item.name) return null
        val dest = File(dir, name)
        if (dest.exists()) return "A file with that name already exists."
        if (!item.file.renameTo(dest)) return "Couldn't rename this file."
        val edit = sp.edit()
        for (key in listOf("starred", "shared")) {
            val s = stringSet(key)
            if (s.remove(item.name)) { s.add(name); edit.putStringSet(key, s) }
        }
        edit.putLong("c_$name", item.created).remove("c_${item.name}").apply()
        items = items.map {
            if (it.name == item.name) it.copy(name = name, path = dest.absolutePath, modified = dest.lastModified()) else it
        }
        showToast("Renamed to $name", ToastKind.SUCCESS)
        return null
    }

    fun delete(item: PdfItem) {
        item.file.delete()
        forget(item.name)
        items = items.filter { it.name != item.name }
        showToast("Deleted ${item.name}", ToastKind.SUCCESS)
    }

    private fun forget(name: String) {
        val edit = sp.edit()
        for (key in listOf("starred", "shared")) {
            val s = stringSet(key)
            if (s.remove(name)) edit.putStringSet(key, s)
        }
        edit.remove("c_$name").apply()
    }

    fun deleteAll() {
        dir.listFiles()?.forEach { it.delete() }
        sp.edit().remove("starred").remove("shared").apply()
        items = emptyList()
        showToast("All PDFs were deleted from this device", ToastKind.SUCCESS)
    }

    fun download(item: PdfItem) {
        viewModelScope.launch {
            val uri = withContext(Dispatchers.IO) {
                try { saveToDownloads(appCtx, item.file, item.name) } catch (e: Throwable) { null }
            }
            if (uri != null) showToast("Saved to Downloads/PDFly", ToastKind.SUCCESS)
            else showToast("Couldn't save the file", ToastKind.ERROR)
        }
    }

    fun sorted(list: List<PdfItem>, by: SortBy = sortBy): List<PdfItem> = when (by) {
        SortBy.NAME -> list.sortedBy { it.name.lowercase(Locale.getDefault()) }
        SortBy.MODIFIED -> list.sortedByDescending { it.modified }
        SortBy.CREATED -> list.sortedByDescending { it.created }
        SortBy.SIZE -> list.sortedByDescending { it.size }
    }
}
