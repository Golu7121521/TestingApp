package com.pdfly.app.data

import androidx.compose.runtime.Immutable
import androidx.compose.ui.geometry.Offset
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ThemeMode(val label: String) { LIGHT("Light"), DARK("Dark"), SYSTEM("System") }

enum class SortBy(val label: String) {
    NAME("Name"),
    MODIFIED("Last modified"),
    CREATED("Date created"),
    SIZE("File size"),
}

enum class ToastKind { SUCCESS, ERROR, INFO }

data class ToastMsg(val id: Long, val text: String, val kind: ToastKind)

@Immutable
data class PdfItem(
    val name: String,
    val path: String,
    val size: Long,
    val pages: Int,
    val modified: Long,
    val created: Long,
    val starred: Boolean,
    val shared: Boolean,
) {
    val file: File get() = File(path)
    val title: String get() = if (name.endsWith(".pdf", ignoreCase = true)) name.dropLast(4) else name
    val pagesLabel: String
        get() = if (pages > 0) "$pages page${if (pages == 1) "" else "s"}" else "Pages unknown"
    val meta: String get() = "${formatSize(size)} · $pagesLabel · ${formatDate(modified)}"
}

/** A freehand stroke. Points are normalised (0..1) relative to the page. */
class Stroke(
    val points: List<Offset>,
    val color: Int,
    val width: Float, // fraction of page width
    val alpha: Int,   // 0..255
)

fun formatSize(bytes: Long): String = when {
    bytes < 1024L -> "$bytes B"
    bytes < 1024L * 1024L -> String.format(Locale.US, "%.0f KB", bytes / 1024.0)
    bytes < 1024L * 1024L * 1024L -> String.format(Locale.US, "%.1f MB", bytes / 1048576.0)
    else -> String.format(Locale.US, "%.2f GB", bytes / 1073741824.0)
}

fun formatDate(ms: Long): String =
    SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(ms))

fun friendlyError(e: Throwable): String = when (e) {
    is SecurityException -> "This PDF is password-protected. Remove the password and try again."
    is OutOfMemoryError -> "Not enough memory to process this file. Try a smaller PDF."
    is IllegalArgumentException -> e.message ?: "That input isn't valid."
    is IOException -> e.message?.takeIf { it.length < 120 } ?: "This file couldn't be read. It may be damaged."
    is IllegalStateException -> "This file couldn't be read. It may be damaged or unsupported."
    else -> "Something went wrong. Please try again."
}

/** Parses "1-3, 5, 8-10" into zero-based page indexes (order kept, duplicates removed). */
fun parsePageRanges(text: String, max: Int): List<Int> {
    val cleaned = text.trim()
    require(cleaned.isNotEmpty()) { "Enter the pages you want, for example 1-3, 5." }
    val out = LinkedHashSet<Int>()
    val pattern = Regex("""^(\d+)\s*(?:-\s*(\d+))?$""")
    for (part in cleaned.split(',', ';')) {
        val p = part.trim()
        if (p.isEmpty()) continue
        val m = pattern.matchEntire(p) ?: throw IllegalArgumentException("\"$p\" isn't a valid page or range.")
        val a = m.groupValues[1].toIntOrNull() ?: throw IllegalArgumentException("\"$p\" is too large.")
        val bText = m.groupValues[2]
        val b = if (bText.isEmpty()) a else (bText.toIntOrNull() ?: throw IllegalArgumentException("\"$p\" is too large."))
        if (a < 1 || b < 1 || a > max || b > max) {
            throw IllegalArgumentException("Pages must be between 1 and $max.")
        }
        if (a > b) throw IllegalArgumentException("\"$p\" goes backwards. Use $b-$a instead.")
        for (i in a..b) out.add(i - 1)
    }
    require(out.isNotEmpty()) { "Enter the pages you want, for example 1-3, 5." }
    return out.toList()
}
