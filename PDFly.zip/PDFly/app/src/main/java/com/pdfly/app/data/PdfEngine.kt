package com.pdfly.app.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.LruCache
import androidx.exifinterface.media.ExifInterface
import androidx.compose.ui.geometry.Offset
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * A rendering session over Google's android.graphics.pdf.PdfRenderer.
 * PdfRenderer is not thread-safe and only allows one open page, so everything is serialised with a mutex.
 */
class PdfSession private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
    val sizes: List<Pair<Int, Int>>,
) {
    private val mutex = Mutex()
    @Volatile private var closed = false
    val pageCount: Int = sizes.size

    private val cache = object : LruCache<String, Bitmap>(64 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    suspend fun render(index: Int, widthPx: Int): Bitmap {
        val key = "$index@$widthPx"
        cache.get(key)?.let { return it }
        return withContext(Dispatchers.IO) {
            mutex.withLock {
                cache.get(key) ?: run {
                    if (closed) throw CancellationException("Session closed")
                    val (pw, ph) = sizes[index]
                    val h = (widthPx.toFloat() * ph / pw).roundToInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    val page = renderer.openPage(index)
                    try {
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    } finally {
                        page.close()
                    }
                    cache.put(key, bmp)
                    bmp
                }
            }
        }
    }

    fun close() {
        closed = true
        CoroutineScope(Dispatchers.IO).launch {
            mutex.withLock {
                try { renderer.close() } catch (_: Throwable) {}
                try { pfd.close() } catch (_: Throwable) {}
            }
        }
    }

    companion object {
        suspend fun open(file: File): PdfSession = withContext(Dispatchers.IO) {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            try {
                val r = PdfRenderer(pfd)
                val list = ArrayList<Pair<Int, Int>>(r.pageCount)
                for (i in 0 until r.pageCount) {
                    val p = r.openPage(i)
                    try { list.add(p.width to p.height) } finally { p.close() }
                }
                PdfSession(pfd, r, list)
            } catch (e: Throwable) {
                try { pfd.close() } catch (_: Throwable) {}
                throw e
            }
        }
    }
}

/** Small page previews with an in-memory cache. */
object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val lock = Mutex()

    suspend fun get(file: File, version: Long, page: Int, widthPx: Int): Bitmap? {
        val key = "${file.absolutePath}|$version|$page|$widthPx"
        cache.get(key)?.let { return it }
        return withContext(Dispatchers.IO) {
            lock.withLock {
                cache.get(key) ?: try {
                    renderOnce(file, page, widthPx)?.also { cache.put(key, it) }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    null
                }
            }
        }
    }

    private fun renderOnce(file: File, page: Int, widthPx: Int): Bitmap? {
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        try {
            val r = PdfRenderer(pfd)
            try {
                if (page !in 0 until r.pageCount) return null
                val p = r.openPage(page)
                try {
                    val h = (widthPx.toFloat() * p.height / p.width).roundToInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return bmp
                } finally {
                    p.close()
                }
            } finally {
                r.close()
            }
        } finally {
            pfd.close()
        }
    }
}

/**
 * Minimal streaming PDF writer: each page is one JPEG image. Memory use stays small because every
 * page is written to disk as soon as it is rendered.
 */
class SimplePdfWriter(private val out: OutputStream) {
    private var pos = 0L
    private val offsets = HashMap<Int, Long>()
    private val pageIds = ArrayList<Int>()
    private var nextId = 3 // 1 = catalog, 2 = page tree

    init {
        raw("%PDF-1.4\n")
        raw(byteArrayOf(0x25, 0xE2.toByte(), 0xE3.toByte(), 0xCF.toByte(), 0xD3.toByte(), 0x0A))
    }

    private fun raw(s: String) = raw(s.toByteArray(Charsets.ISO_8859_1))
    private fun raw(b: ByteArray) { out.write(b); pos += b.size }
    private fun f(v: Float) = String.format(Locale.US, "%.2f", v)

    fun addPage(jpeg: ByteArray, imgW: Int, imgH: Int, pageW: Float, pageH: Float) {
        val imgId = nextId++
        val contId = nextId++
        val pageId = nextId++
        offsets[imgId] = pos
        raw("$imgId 0 obj\n<< /Type /XObject /Subtype /Image /Width $imgW /Height $imgH " +
            "/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.size} >>\nstream\n")
        raw(jpeg)
        raw("\nendstream\nendobj\n")
        val content = "q ${f(pageW)} 0 0 ${f(pageH)} 0 0 cm /Im0 Do Q"
        offsets[contId] = pos
        raw("$contId 0 obj\n<< /Length ${content.length} >>\nstream\n$content\nendstream\nendobj\n")
        offsets[pageId] = pos
        raw("$pageId 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${f(pageW)} ${f(pageH)}] " +
            "/Resources << /XObject << /Im0 $imgId 0 R >> >> /Contents $contId 0 R >>\nendobj\n")
        pageIds.add(pageId)
    }

    fun finish() {
        offsets[2] = pos
        raw("2 0 obj\n<< /Type /Pages /Count ${pageIds.size} /Kids [${pageIds.joinToString(" ") { "$it 0 R" }}] >>\nendobj\n")
        offsets[1] = pos
        raw("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")
        val xrefPos = pos
        raw("xref\n0 $nextId\n")
        raw("0000000000 65535 f \n")
        for (id in 1 until nextId) {
            raw(String.format(Locale.US, "%010d 00000 n \n", offsets[id] ?: 0L))
        }
        raw("trailer\n<< /Size $nextId /Root 1 0 R >>\nstartxref\n$xrefPos\n%%EOF\n")
        out.flush()
    }
}

class PageSpec(
    val file: File,
    val index: Int,
    val rotation: Int = 0,
    val overlay: ((Canvas, Int, Int) -> Unit)? = null,
)

object PdfOps {
    private const val MAX_SIDE_PX = 3000f
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    fun probePages(file: File): Int {
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        try {
            val r = PdfRenderer(pfd)
            try {
                return r.pageCount
            } finally {
                r.close()
            }
        } finally {
            pfd.close()
        }
    }

    suspend fun pageCount(file: File): Int = withContext(Dispatchers.IO) { probePages(file) }

    private fun jpegBytes(bmp: Bitmap, quality: Int): ByteArray {
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, bos)
        return bos.toByteArray()
    }

    /**
     * Renders the given pages with Google's PdfRenderer and writes them to a new PDF.
     * [scale] = render resolution relative to 72 dpi, [quality] = JPEG quality 1..100.
     */
    suspend fun export(
        out: File,
        specs: List<PageSpec>,
        scale: Float = 2f,
        quality: Int = 85,
        onProgress: (Float) -> Unit = {},
    ) {
        withContext(Dispatchers.IO) {
            require(specs.isNotEmpty()) { "There are no pages to write." }
            val opened = HashMap<String, Pair<ParcelFileDescriptor, PdfRenderer>>()
            val os = BufferedOutputStream(FileOutputStream(out), 64 * 1024)
            var ok = false
            try {
                val writer = SimplePdfWriter(os)
                specs.forEachIndexed { n, spec ->
                    ensureActive()
                    val renderer = opened.getOrPut(spec.file.absolutePath) {
                        val pfd = ParcelFileDescriptor.open(spec.file, ParcelFileDescriptor.MODE_READ_ONLY)
                        try {
                            pfd to PdfRenderer(pfd)
                        } catch (e: Throwable) {
                            pfd.close()
                            throw e
                        }
                    }.second

                    val page = renderer.openPage(spec.index)
                    val pw = page.width
                    val ph = page.height
                    val rendered: Bitmap = try {
                        val s = min(scale, MAX_SIDE_PX / max(pw, ph).toFloat())
                        val bw = (pw * s).roundToInt().coerceAtLeast(1)
                        val bh = (ph * s).roundToInt().coerceAtLeast(1)
                        val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
                        b.eraseColor(Color.WHITE)
                        page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                        b
                    } finally {
                        page.close()
                    }

                    spec.overlay?.invoke(Canvas(rendered), rendered.width, rendered.height)

                    val rot = ((spec.rotation % 360) + 360) % 360
                    var work = rendered
                    if (rot != 0) {
                        val m = Matrix()
                        m.postRotate(rot.toFloat())
                        work = Bitmap.createBitmap(rendered, 0, 0, rendered.width, rendered.height, m, true)
                        rendered.recycle()
                    }
                    val jpeg = jpegBytes(work, quality)
                    val iw = work.width
                    val ih = work.height
                    work.recycle()

                    val sideways = rot == 90 || rot == 270
                    val outW = (if (sideways) ph else pw).toFloat()
                    val outH = (if (sideways) pw else ph).toFloat()
                    writer.addPage(jpeg, iw, ih, outW, outH)
                    onProgress((n + 1f) / specs.size)
                }
                writer.finish()
                os.flush()
                ok = true
            } finally {
                try { os.close() } catch (_: Throwable) {}
                opened.values.forEach {
                    try { it.second.close() } catch (_: Throwable) {}
                    try { it.first.close() } catch (_: Throwable) {}
                }
                if (!ok) out.delete()
            }
        }
    }

    private fun decodeImage(ctx: Context, uri: Uri): Bitmap? {
        val resolver = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 2600) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        val orientation = try {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (_: Throwable) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        val upright = if (degrees != 0f) {
            val m = Matrix().apply { postRotate(degrees) }
            Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true).also { decoded.recycle() }
        } else decoded

        // Flatten transparency onto white so JPEG doesn't turn it black.
        val flat = Bitmap.createBitmap(upright.width, upright.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(flat)
        c.drawColor(Color.WHITE)
        c.drawBitmap(upright, 0f, 0f, null)
        upright.recycle()
        return flat
    }

    suspend fun imagesToPdf(ctx: Context, uris: List<Uri>, out: File, onProgress: (Float) -> Unit) {
        withContext(Dispatchers.IO) {
            require(uris.isNotEmpty()) { "Choose at least one image." }
            val os = BufferedOutputStream(FileOutputStream(out), 64 * 1024)
            var ok = false
            try {
                val writer = SimplePdfWriter(os)
                uris.forEachIndexed { i, uri ->
                    ensureActive()
                    val bmp = decodeImage(ctx, uri) ?: throw IOException("One of the images couldn't be read.")
                    val jpeg = jpegBytes(bmp, 88)
                    val pageW = 595f
                    val pageH = pageW * bmp.height / bmp.width
                    writer.addPage(jpeg, bmp.width, bmp.height, pageW, pageH)
                    bmp.recycle()
                    onProgress((i + 1f) / uris.size)
                }
                writer.finish()
                os.flush()
                ok = true
            } finally {
                try { os.close() } catch (_: Throwable) {}
                if (!ok) out.delete()
            }
        }
    }

    /** Saves every page as PNG/JPEG into Pictures/PDFly. Returns the number of images written. */
    suspend fun pdfToImages(
        ctx: Context,
        file: File,
        png: Boolean,
        baseName: String,
        onProgress: (Float) -> Unit,
    ): Int = withContext(Dispatchers.IO) {
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        try {
            val r = PdfRenderer(pfd)
            try {
                val total = r.pageCount
                for (i in 0 until total) {
                    ensureActive()
                    val page = r.openPage(i)
                    val bmp: Bitmap = try {
                        val s = min(2f, MAX_SIDE_PX / max(page.width, page.height).toFloat())
                        val b = Bitmap.createBitmap(
                            (page.width * s).roundToInt().coerceAtLeast(1),
                            (page.height * s).roundToInt().coerceAtLeast(1),
                            Bitmap.Config.ARGB_8888,
                        )
                        b.eraseColor(Color.WHITE)
                        page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                        b
                    } finally {
                        page.close()
                    }
                    val ext = if (png) "png" else "jpg"
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "$baseName page ${i + 1}.$ext")
                        put(MediaStore.Images.Media.MIME_TYPE, if (png) "image/png" else "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PDFly")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        ?: throw IOException("Couldn't save to your gallery.")
                    ctx.contentResolver.openOutputStream(uri)?.use { os ->
                        bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 92, os)
                    } ?: throw IOException("Couldn't save to your gallery.")
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    ctx.contentResolver.update(uri, values, null, null)
                    bmp.recycle()
                    onProgress((i + 1f) / total)
                }
                total
            } finally {
                r.close()
            }
        } finally {
            pfd.close()
        }
    }

    // ---------- drawing helpers (annotations & signature) ----------

    fun drawStrokes(canvas: Canvas, w: Int, h: Int, strokes: List<Stroke>) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        for (s in strokes) {
            if (s.points.isEmpty()) continue
            p.color = s.color
            p.alpha = s.alpha
            p.strokeWidth = s.width * w
            val path = Path()
            val first = s.points[0]
            path.moveTo(first.x * w, first.y * h)
            if (s.points.size == 1) {
                path.lineTo(first.x * w + 0.1f, first.y * h)
            } else {
                for (i in 1 until s.points.size) path.lineTo(s.points[i].x * w, s.points[i].y * h)
            }
            canvas.drawPath(path, p)
        }
    }

    fun drawSignature(canvas: Canvas, w: Int, h: Int, sig: Bitmap, cx: Float, cy: Float, widthFrac: Float) {
        val sw = widthFrac * w
        val sh = sw * sig.height / sig.width
        val rect = RectF(cx * w - sw / 2f, cy * h - sh / 2f, cx * w + sw / 2f, cy * h + sh / 2f)
        canvas.drawBitmap(sig, null, rect, bmpPaint)
    }

    /** Builds a transparent bitmap from signature-pad strokes (points normalised to the pad). */
    fun signatureFromStrokes(strokes: List<List<Offset>>, padAspect: Float, color: Int): Bitmap? {
        val pts = strokes.flatten()
        if (pts.isEmpty()) return null
        val minX = pts.minOf { it.x }
        val maxX = pts.maxOf { it.x }
        val minY = pts.minOf { it.y }
        val maxY = pts.maxOf { it.y }
        val padW = 1200f
        val padH = padW / padAspect
        val margin = 24f
        val bw = ((maxX - minX) * padW + margin * 2).roundToInt().coerceAtLeast(48)
        val bh = ((maxY - minY) * padH + margin * 2).roundToInt().coerceAtLeast(48)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            style = Paint.Style.STROKE
            strokeWidth = 9f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        for (s in strokes) {
            if (s.isEmpty()) continue
            val path = Path()
            path.moveTo((s[0].x - minX) * padW + margin, (s[0].y - minY) * padH + margin)
            if (s.size == 1) path.lineTo((s[0].x - minX) * padW + margin + 0.1f, (s[0].y - minY) * padH + margin)
            for (i in 1 until s.size) path.lineTo((s[i].x - minX) * padW + margin, (s[i].y - minY) * padH + margin)
            c.drawPath(path, paint)
        }
        return bmp
    }

    fun signatureFromText(text: String, color: Int): Bitmap? {
        val t = text.trim()
        if (t.isEmpty()) return null
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
            textSize = 160f
        }
        val fm = paint.fontMetrics
        val w = (paint.measureText(t) + 40f).roundToInt().coerceAtLeast(48)
        val h = (fm.descent - fm.ascent + 30f).roundToInt().coerceAtLeast(48)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(bmp).drawText(t, 20f, 15f - fm.ascent, paint)
        return bmp
    }
}

fun saveToDownloads(ctx: Context, file: File, displayName: String): Uri? {
    val values = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, displayName)
        put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PDFly")
        put(MediaStore.Downloads.IS_PENDING, 1)
    }
    val resolver = ctx.contentResolver
    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
    try {
        resolver.openOutputStream(uri)?.use { os -> file.inputStream().use { it.copyTo(os) } }
            ?: return null
    } catch (e: Throwable) {
        resolver.delete(uri, null, null)
        throw e
    }
    values.clear()
    values.put(MediaStore.Downloads.IS_PENDING, 0)
    resolver.update(uri, values, null, null)
    return uri
}
