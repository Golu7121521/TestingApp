package com.pdfly.app.ui

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Redo
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.outlined.BorderColor
import androidx.compose.material.icons.outlined.Brush
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Draw
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.pdfly.app.data.AppViewModel
import com.pdfly.app.data.PageSpec
import com.pdfly.app.data.PdfItem
import com.pdfly.app.data.PdfOps
import com.pdfly.app.data.PdfSession
import com.pdfly.app.data.Stroke
import com.pdfly.app.data.ToastKind
import kotlinx.coroutines.CancellationException

/** Shows one PDF page, fitted into the available space, with an overlay layer on top. */
@Composable
private fun PageStage(
    session: PdfSession,
    page: Int,
    modifier: Modifier = Modifier,
    overlay: @Composable () -> Unit,
) {
    val (pw, ph) = session.sizes[page]
    val ratio = pw.toFloat() / ph
    val bmp by produceState<Bitmap?>(null, page, session) {
        value = try { session.render(page, 1100) } catch (e: CancellationException) { throw e } catch (e: Throwable) { null }
    }
    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val w = minOf(maxWidth, maxHeight * ratio)
        Box(Modifier.size(w, w / ratio).background(Color.White).border(1.dp, Pdfly.colors.border)) {
            val b = bmp
            if (b != null) Image(b.asImageBitmap(), "Page ${page + 1}", Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
            else Skeleton(Modifier.fillMaxSize(), androidx.compose.foundation.shape.RoundedCornerShape(0.dp))
            overlay()
        }
    }
}

@Composable
private fun PageNavRow(page: Int, total: Int, onPage: (Int) -> Unit, trailing: @Composable () -> Unit = {}) {
    val c = Pdfly.colors
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconBtn(Icons.Outlined.ChevronLeft, "Previous page", { onPage(page - 1) }, enabled = page > 0)
        Text("Page ${page + 1} / $total", style = Type.bodyMedium, color = c.text)
        IconBtn(Icons.Outlined.ChevronRight, "Next page", { onPage(page + 1) }, enabled = page < total - 1)
        Box(Modifier.weight(1f)) {}
        trailing()
    }
}

@Composable
private fun EditorLoading(session: PdfSession?, error: String?, onBack: () -> Unit) {
    when {
        error != null -> ErrorState(error, null, onBack, "Choose another file")
        session == null -> Column(Modifier.fillMaxSize().padding(24.dp)) { ProgressBlock("Opening PDF…", null) }
    }
}

// ------------------------------------------------------------------ EDIT (draw & highlight)

private val penColors = listOf(0xFF0F172A, 0xFF2563EB, 0xFFEF4444, 0xFF22C55E).map { it.toInt() }
private val highlightColors = listOf(0xFFFACC15, 0xFF4ADE80, 0xFFF472B6, 0xFF60A5FA).map { it.toInt() }

@Composable
fun EditTool(vm: AppViewModel, open: (PdfItem) -> Unit) {
    var file by remember { mutableStateOf<PdfItem?>(null) }
    val f = file
    if (f == null) {
        ToolScaffold(false, "Edit PDF", "Draw and highlight on your PDF pages.") {
            PickPdfZone(vm, false) { file = it.firstOrNull() }
        }
    } else {
        androidx.compose.runtime.key(f.path) { EditorBody(vm, f, open) { file = null } }
    }
}

@Composable
private fun EditorBody(vm: AppViewModel, f: PdfItem, open: (PdfItem) -> Unit, onChange: () -> Unit) {
    val c = Pdfly.colors
    val (session, error) = rememberPdfSession(f.file)
    val runner = rememberRunner()
    var page by remember { mutableStateOf(0) }
    var tool by remember { mutableStateOf(0) } // 0 pen, 1 highlighter
    var colorIdx by remember { mutableStateOf(1) }
    val strokes = remember { mutableStateMapOf<Int, List<Stroke>>() }
    val redo = remember { mutableStateMapOf<Int, List<Stroke>>() }
    var live by remember { mutableStateOf<List<Offset>>(emptyList()) }

    if (session == null || error != null) { EditorLoading(session, error, onChange); return }

    val palette = if (tool == 0) penColors else highlightColors
    val color = palette[colorIdx.coerceIn(0, palette.size - 1)]
    val total = session.pageCount
    val anyStrokes = strokes.values.any { it.isNotEmpty() }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().background(c.surface).padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Pen", tool == 0) { tool = 0; colorIdx = 1 }
                Chip("Highlighter", tool == 1) { tool = 1; colorIdx = 0 }
                palette.forEachIndexed { i, col ->
                    Box(
                        Modifier.size(32.dp).clip(CircleShape).background(Color(col))
                            .border(if (i == colorIdx) 3.dp else 1.dp, if (i == colorIdx) c.primaryActive else c.border, CircleShape)
                            .clickable(role = Role.RadioButton) { colorIdx = i }
                            .semantics { selected = i == colorIdx; contentDescription = "Colour ${i + 1}" },
                    )
                }
                IconBtn(Icons.AutoMirrored.Outlined.Undo, "Undo", {
                    val l = strokes[page].orEmpty()
                    if (l.isNotEmpty()) { redo[page] = redo[page].orEmpty() + l.last(); strokes[page] = l.dropLast(1); runner.reset() }
                }, enabled = strokes[page].orEmpty().isNotEmpty())
                IconBtn(Icons.AutoMirrored.Outlined.Redo, "Redo", {
                    val r = redo[page].orEmpty()
                    if (r.isNotEmpty()) { strokes[page] = strokes[page].orEmpty() + r.last(); redo[page] = r.dropLast(1) }
                }, enabled = redo[page].orEmpty().isNotEmpty())
                IconBtn(Icons.Outlined.DeleteOutline, "Clear drawings on this page", { strokes[page] = emptyList(); redo[page] = emptyList() }, enabled = strokes[page].orEmpty().isNotEmpty(), tint = c.error)
            }
            PageNavRow(page, total, { page = it.coerceIn(0, total - 1); live = emptyList() }) {
                PButton("Change file", onChange, style = BtnStyle.Ghost)
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth().background(c.canvas).padding(12.dp)) {
            PageStage(session, page, Modifier.fillMaxSize()) {
                Canvas(
                    Modifier.fillMaxSize().pointerInput(page, tool, colorIdx) {
                        fun norm(o: Offset) = Offset((o.x / size.width).coerceIn(0f, 1f), (o.y / size.height).coerceIn(0f, 1f))
                        detectDragGestures(
                            onDragStart = { live = listOf(norm(it)) },
                            onDragCancel = { live = emptyList() },
                            onDragEnd = {
                                if (live.isNotEmpty()) {
                                    val s = Stroke(live, color, if (tool == 0) 0.004f else 0.026f, if (tool == 0) 255 else 105)
                                    strokes[page] = strokes[page].orEmpty() + s
                                    redo[page] = emptyList()
                                    runner.reset()
                                }
                                live = emptyList()
                            },
                        ) { change, _ ->
                            change.consume()
                            live = live + norm(change.position)
                        }
                    },
                ) {
                    fun draw(pts: List<Offset>, col: Int, widthFrac: Float, alpha: Int) {
                        if (pts.isEmpty()) return
                        val path = Path()
                        path.moveTo(pts[0].x * size.width, pts[0].y * size.height)
                        if (pts.size == 1) path.lineTo(pts[0].x * size.width + 0.1f, pts[0].y * size.height)
                        for (i in 1 until pts.size) path.lineTo(pts[i].x * size.width, pts[i].y * size.height)
                        drawPath(path, Color(col).copy(alpha = alpha / 255f), style = DrawStroke(width = widthFrac * size.width, cap = StrokeCap.Round, join = StrokeJoin.Round))
                    }
                    strokes[page].orEmpty().forEach { draw(it.points, it.color, it.width, it.alpha) }
                    draw(live, color, if (tool == 0) 0.004f else 0.026f, if (tool == 0) 255 else 105)
                }
            }
        }

        Column(Modifier.fillMaxWidth().background(c.surface).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            RunnerPanel(runner, vm, open)
            Text("Drawings are saved into a new copy of the PDF as part of the page (they can't be edited later). Your original stays unchanged.", style = Type.small, color = c.textMuted)
            PButton("Save annotated PDF", {
                val snapshot = strokes.toMap()
                runner.start("Saving annotated PDF…") {
                    val out = vm.newOutputFile("${f.title} (annotated)")
                    val specs = (0 until total).map { i ->
                        val l = snapshot[i].orEmpty()
                        val overlay: (AndroidCanvas, Int, Int) -> Unit = { cv, w, h -> PdfOps.drawStrokes(cv, w, h, l) }
                        PageSpec(f.file, i, 0, if (l.isEmpty()) null else overlay)
                    }
                    PdfOps.export(out, specs, 2f, 88) { progress = it }
                    val item = vm.registerOutput(out)
                    results = listOf(item)
                    note = "Saved ${item.name}."
                    vm.showToast("Annotated PDF saved", ToastKind.SUCCESS)
                }
            }, Modifier.fillMaxWidth(), icon = Icons.Outlined.Brush, enabled = anyStrokes && !runner.running)
        }
    }
}

// ------------------------------------------------------------------ SIGN

private class Placement(val cx: Float, val cy: Float, val w: Float)

@Composable
fun SignTool(vm: AppViewModel, open: (PdfItem) -> Unit) {
    var file by remember { mutableStateOf<PdfItem?>(null) }
    val f = file
    if (f == null) {
        ToolScaffold(false, "Sign PDF", "Draw or type your signature and place it on a page.") {
            PickPdfZone(vm, false) { file = it.firstOrNull() }
        }
    } else {
        androidx.compose.runtime.key(f.path) { SignBody(vm, f, open) { file = null } }
    }
}

@Composable
private fun SignBody(vm: AppViewModel, f: PdfItem, open: (PdfItem) -> Unit, onChange: () -> Unit) {
    val c = Pdfly.colors
    val (session, error) = rememberPdfSession(f.file)
    val runner = rememberRunner()
    var page by remember { mutableStateOf(0) }
    var sig by remember { mutableStateOf<Bitmap?>(null) }
    var creating by remember { mutableStateOf(false) }
    val placements = remember { mutableStateMapOf<Int, Placement>() }

    if (session == null || error != null) { EditorLoading(session, error, onChange); return }
    val total = session.pageCount
    val here = placements[page]

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().background(c.surface).padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PageNavRow(page, total, { page = it.coerceIn(0, total - 1) }) { PButton("Change file", onChange, style = BtnStyle.Ghost) }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                PButton(if (sig == null) "Create signature" else "Change signature", { creating = true }, style = if (sig == null) BtnStyle.Primary else BtnStyle.Secondary, icon = Icons.Outlined.Draw)
                if (sig != null) {
                    if (here == null) PButton("Add to this page", { placements[page] = Placement(0.5f, 0.85f, 0.32f); runner.reset() })
                    else PButton("Remove from this page", { placements.remove(page); runner.reset() }, style = BtnStyle.Secondary)
                }
            }
            if (sig != null && here != null) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Size", style = Type.secondary, color = c.textSecondary)
                    Slider(
                        here.w, { placements[page] = Placement(here.cx, here.cy, it) }, Modifier.weight(1f), valueRange = 0.1f..0.7f,
                        colors = SliderDefaults.colors(thumbColor = c.primary, activeTrackColor = c.primary, inactiveTrackColor = c.primarySurface),
                    )
                }
            }
            val hint = when {
                sig == null -> "Start by creating your signature."
                here == null -> "Tap “Add to this page” to place your signature."
                else -> "Drag the signature to position it. This preview is exactly what will be saved."
            }
            Text(hint, style = Type.small, color = c.textSecondary)
        }

        Box(Modifier.weight(1f).fillMaxWidth().background(c.canvas).padding(12.dp)) {
            PageStage(session, page, Modifier.fillMaxSize()) {
                val s = sig
                if (s != null && here != null) {
                    val img = remember(s) { s.asImageBitmap() }
                    Canvas(
                        Modifier.fillMaxSize().pointerInput(page, here.w) {
                            detectDragGestures { change, drag ->
                                change.consume()
                                val cur = placements[page] ?: return@detectDragGestures
                                placements[page] = Placement(
                                    (cur.cx + drag.x / size.width).coerceIn(0f, 1f),
                                    (cur.cy + drag.y / size.height).coerceIn(0f, 1f),
                                    cur.w,
                                )
                            }
                        },
                    ) {
                        val sw = here.w * size.width
                        val sh = sw * s.height / s.width
                        val left = here.cx * size.width - sw / 2f
                        val top = here.cy * size.height - sh / 2f
                        drawImage(img, dstOffset = IntOffset(left.toInt(), top.toInt()), dstSize = IntSize(sw.toInt().coerceAtLeast(1), sh.toInt().coerceAtLeast(1)))
                        drawRoundRect(
                            c.primary, topLeft = Offset(left, top), size = androidx.compose.ui.geometry.Size(sw, sh),
                            cornerRadius = CornerRadius(8f), style = DrawStroke(2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))),
                        )
                    }
                }
            }
        }

        Column(Modifier.fillMaxWidth().background(c.surface).navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            RunnerPanel(runner, vm, open)
            Text("This places an image of your signature on the page. It is not a certified or legally verified digital signature.", style = Type.small, color = c.textMuted)
            PButton("Apply & save PDF", {
                val s = sig ?: return@PButton
                val snapshot = placements.toMap()
                runner.start("Saving signed PDF…") {
                    val out = vm.newOutputFile("${f.title} (signed)")
                    val specs = (0 until total).map { i ->
                        val p = snapshot[i]
                        val overlay: (AndroidCanvas, Int, Int) -> Unit = { cv, w, h ->
                            if (p != null) PdfOps.drawSignature(cv, w, h, s, p.cx, p.cy, p.w)
                        }
                        PageSpec(f.file, i, 0, if (p == null) null else overlay)
                    }
                    PdfOps.export(out, specs, 2f, 90) { progress = it }
                    val item = vm.registerOutput(out)
                    results = listOf(item)
                    note = "Signed copy saved as ${item.name}."
                    vm.showToast("Signed PDF saved", ToastKind.SUCCESS)
                }
            }, Modifier.fillMaxWidth(), enabled = sig != null && placements.isNotEmpty() && !runner.running)
        }
    }

    if (creating) SignatureDialog(onDismiss = { creating = false }, onDone = { sig = it; creating = false; runner.reset() })
}

@Composable
private fun SignatureDialog(onDismiss: () -> Unit, onDone: (Bitmap) -> Unit) {
    val c = Pdfly.colors
    var tab by remember { mutableStateOf(0) }
    var typed by remember { mutableStateOf("") }
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var live by remember { mutableStateOf<List<Offset>>(emptyList()) }
    val ink = 0xFF0F172A.toInt()
    val aspect = 2.4f
    val typedBmp = remember(typed) { PdfOps.signatureFromText(typed, ink) }

    PdfDialog("Your signature", onDismiss, content = {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Draw", tab == 0) { tab = 0 }
            Chip("Type", tab == 1) { tab = 1 }
        }
        if (tab == 0) {
            Box(Modifier.fillMaxWidth().aspectRatio(aspect).clip(Radius.md).background(Color.White).border(1.dp, c.border, Radius.md)) {
                Canvas(
                    Modifier.fillMaxSize().pointerInput(Unit) {
                        fun norm(o: Offset) = Offset((o.x / size.width).coerceIn(0f, 1f), (o.y / size.height).coerceIn(0f, 1f))
                        detectDragGestures(
                            onDragStart = { live = listOf(norm(it)) },
                            onDragCancel = { live = emptyList() },
                            onDragEnd = { if (live.isNotEmpty()) strokes.add(live); live = emptyList() },
                        ) { change, _ -> change.consume(); live = live + norm(change.position) }
                    },
                ) {
                    (strokes.toList() + listOf(live)).forEach { pts ->
                        if (pts.isEmpty()) return@forEach
                        val p = Path()
                        p.moveTo(pts[0].x * size.width, pts[0].y * size.height)
                        if (pts.size == 1) p.lineTo(pts[0].x * size.width + 0.1f, pts[0].y * size.height)
                        for (i in 1 until pts.size) p.lineTo(pts[i].x * size.width, pts[i].y * size.height)
                        drawPath(p, Color(ink), style = DrawStroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                    }
                }
                if (strokes.isEmpty() && live.isEmpty()) Text("Sign here", style = Type.secondary, color = Color(0xFF94A3B8), modifier = Modifier.align(Alignment.Center))
            }
        } else {
            PdfTextField(typed, { typed = it.take(40) }, "Type your name", Modifier.fillMaxWidth(), label = "Typed signature")
            Box(Modifier.fillMaxWidth().aspectRatio(aspect).clip(Radius.md).background(Color.White).border(1.dp, c.border, Radius.md), contentAlignment = Alignment.Center) {
                val b = typedBmp
                if (b != null) Image(b.asImageBitmap(), "Signature preview", Modifier.padding(16.dp).fillMaxSize(), contentScale = ContentScale.Fit)
            }
        }
    }) {
        if (tab == 0) PButton("Clear", { strokes.clear(); live = emptyList() }, style = BtnStyle.Ghost, enabled = strokes.isNotEmpty())
        PButton("Cancel", onDismiss, style = BtnStyle.Secondary)
        PButton("Use", {
            val bmp = if (tab == 0) PdfOps.signatureFromStrokes(strokes.toList(), aspect, ink) else typedBmp
            if (bmp != null) onDone(bmp)
        }, enabled = if (tab == 0) strokes.isNotEmpty() else typedBmp != null)
    }
}
