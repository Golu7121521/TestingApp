package com.pdfly.app.ui

import android.provider.Settings
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pdfly.app.data.ThemeMode

/**
 * Centralised theme configuration.
 * To change the accent colour of the whole app, edit [Accent] below - nothing else needs touching.
 */
object Accent {
    val primary = Color(0xFF60A5FA)        // Light Blue
    val hover = Color(0xFF3B82F6)
    val active = Color(0xFF2563EB)
    val soft = Color(0xFFEFF6FF)           // Light Blue Background
    val surface = Color(0xFFDBEAFE)        // Light Blue Surface
    val border = Color(0xFFBFDBFE)         // Light Blue Border
    val onPrimary = Color(0xFF0B1B33)      // dark navy: white on #60A5FA is only ~2.5:1 contrast
}

@Immutable
class PdflyColors(
    val dark: Boolean,
    val primary: Color,
    val primaryHover: Color,
    val primaryActive: Color,
    val onPrimary: Color,
    val primarySoft: Color,
    val primarySurface: Color,
    val primaryBorder: Color,
    val accentText: Color,
    val background: Color,
    val sidebar: Color,
    val surface: Color,
    val elevated: Color,
    val text: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val border: Color,
    val divider: Color,
    val canvas: Color,
    val success: Color,
    val warning: Color,
    val error: Color,
    val info: Color,
    val highlight: Color,
)

val LightPdflyColors = PdflyColors(
    dark = false,
    primary = Accent.primary,
    primaryHover = Accent.hover,
    primaryActive = Accent.active,
    onPrimary = Accent.onPrimary,
    primarySoft = Accent.soft,
    primarySurface = Accent.surface,
    primaryBorder = Accent.border,
    accentText = Accent.active,
    background = Color(0xFFF8FAFC),
    sidebar = Color(0xFFFFFFFF),
    surface = Color(0xFFFFFFFF),
    elevated = Color(0xFFFFFFFF),
    text = Color(0xFF0F172A),
    textSecondary = Color(0xFF64748B),
    textMuted = Color(0xFF94A3B8),
    border = Color(0xFFE2E8F0),
    divider = Color(0xFFF1F5F9),
    canvas = Color(0xFFF1F5F9),
    success = Color(0xFF22C55E),
    warning = Color(0xFFF59E0B),
    error = Color(0xFFEF4444),
    info = Color(0xFF3B82F6),
    highlight = Color(0xFFFACC15),
)

val DarkPdflyColors = PdflyColors(
    dark = true,
    primary = Accent.primary,
    primaryHover = Accent.hover,
    primaryActive = Accent.active,
    onPrimary = Accent.onPrimary,
    primarySoft = Color(0xFF16263F),
    primarySurface = Color(0xFF1B3358),
    primaryBorder = Color(0xFF2B4A7A),
    accentText = Accent.primary,
    background = Color(0xFF0B1220),
    sidebar = Color(0xFF111827),
    surface = Color(0xFF111827),
    elevated = Color(0xFF1F2937),
    text = Color(0xFFF8FAFC),
    textSecondary = Color(0xFFCBD5E1),
    textMuted = Color(0xFF94A3B8),
    border = Color(0xFF334155),
    divider = Color(0xFF1F2937),
    canvas = Color(0xFF0F1626),
    success = Color(0xFF22C55E),
    warning = Color(0xFFF59E0B),
    error = Color(0xFFEF4444),
    info = Color(0xFF60A5FA),
    highlight = Color(0xFFFACC15),
)

val LocalPdfly = compositionLocalOf { LightPdflyColors }
val LocalReducedMotion = compositionLocalOf { false }

object Radius {
    val sm = RoundedCornerShape(10.dp)
    val md = RoundedCornerShape(12.dp)
    val lg = RoundedCornerShape(16.dp)
    val xl = RoundedCornerShape(20.dp)
}

object Pdfly {
    val colors: PdflyColors
        @Composable @ReadOnlyComposable get() = LocalPdfly.current
}

private val Font = FontFamily.SansSerif

private fun ts(size: Int, weight: FontWeight, lh: Int, ls: Float = 0f) =
    TextStyle(fontFamily = Font, fontSize = size.sp, fontWeight = weight, lineHeight = lh.sp, letterSpacing = ls.sp)

object Type {
    val pageTitle = ts(28, FontWeight.Bold, 34, -0.5f)
    val section = ts(19, FontWeight.SemiBold, 26, -0.2f)
    val cardTitle = ts(16, FontWeight.SemiBold, 22)
    val body = ts(14, FontWeight.Normal, 21)
    val bodyMedium = ts(14, FontWeight.Medium, 21)
    val secondary = ts(13, FontWeight.Normal, 18)
    val small = ts(12, FontWeight.Normal, 16)
    val button = ts(14, FontWeight.SemiBold, 20)
}

@Composable
fun PdflyTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val c = if (dark) DarkPdflyColors else LightPdflyColors
    val ctx = LocalContext.current
    val reduced = remember {
        try {
            Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        } catch (_: Throwable) {
            false
        }
    }

    val scheme = if (dark) {
        darkColorScheme(
            primary = c.primary, onPrimary = c.onPrimary, primaryContainer = c.primarySurface,
            onPrimaryContainer = c.text, secondary = c.primary, background = c.background,
            onBackground = c.text, surface = c.surface, onSurface = c.text, surfaceVariant = c.elevated,
            onSurfaceVariant = c.textSecondary, outline = c.border, outlineVariant = c.border, error = c.error,
        )
    } else {
        lightColorScheme(
            primary = c.primary, onPrimary = c.onPrimary, primaryContainer = c.primarySurface,
            onPrimaryContainer = c.text, secondary = c.primary, background = c.background,
            onBackground = c.text, surface = c.surface, onSurface = c.text, surfaceVariant = c.primarySoft,
            onSurfaceVariant = c.textSecondary, outline = c.border, outlineVariant = c.border, error = c.error,
        )
    }

    CompositionLocalProvider(LocalPdfly provides c, LocalReducedMotion provides reduced) {
        MaterialTheme(
            colorScheme = scheme,
            typography = Typography(
                bodyLarge = Type.body, bodyMedium = Type.body, bodySmall = Type.secondary,
                titleLarge = Type.section, titleMedium = Type.cardTitle, labelLarge = Type.button,
            ),
            content = content,
        )
    }
}
