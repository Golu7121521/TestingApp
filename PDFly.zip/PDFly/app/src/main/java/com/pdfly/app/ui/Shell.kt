package com.pdfly.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Compress
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Draw
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.MergeType
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material.icons.outlined.Sync
import androidx.compose.material.icons.outlined.ViewSidebar
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.pdfly.app.data.AppViewModel
import com.pdfly.app.data.PdfItem
import com.pdfly.app.data.ThemeMode
import kotlinx.coroutines.launch

enum class Dest(val label: String, val icon: ImageVector, val group: String) {
    HOME("Home", Icons.Outlined.Home, "WORKSPACE"),
    ALL("All PDFs", Icons.Outlined.Folder, "WORKSPACE"),
    RECENT("Recent Files", Icons.Outlined.Schedule, "WORKSPACE"),
    STARRED("Starred", Icons.Outlined.StarOutline, "WORKSPACE"),
    SHARED("Shared Files", Icons.Outlined.People, "WORKSPACE"),
    MERGE("Merge PDF", Icons.Outlined.MergeType, "PDF TOOLS"),
    SPLIT("Split PDF", Icons.Outlined.ContentCut, "PDF TOOLS"),
    COMPRESS("Compress PDF", Icons.Outlined.Compress, "PDF TOOLS"),
    CONVERT("Convert PDF", Icons.Outlined.Sync, "PDF TOOLS"),
    EDIT("Edit PDF", Icons.Outlined.Edit, "PDF TOOLS"),
    SIGN("Sign PDF", Icons.Outlined.Draw, "PDF TOOLS"),
    ORGANIZE("Organize Pages", Icons.Outlined.Layers, "PDF TOOLS"),
    SETTINGS("Settings", Icons.Outlined.Settings, "PREFERENCES"),
    HELP("Help & Support", Icons.Outlined.Info, "PREFERENCES"),
}

@Composable
fun PdflyApp(vm: AppViewModel) {
    val c = Pdfly.colors
    var dest by rememberSaveable { mutableStateOf(Dest.HOME) }
    var viewing by rememberSaveable { mutableStateOf<String?>(null) }
    var searching by rememberSaveable { mutableStateOf(false) }
    var collapsed by rememberSaveable { mutableStateOf(false) }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.importAsync(uris) { if (it.isNotEmpty() && dest == Dest.HOME) dest = Dest.ALL }
    }
    val upload = { picker.launch(arrayOf("application/pdf")) }

    // PDFs opened from other apps ("Open with" / Share)
    val incoming = vm.pendingIncoming
    LaunchedEffect(incoming) {
        if (incoming != null) {
            vm.pendingIncoming = null
            val added = vm.importUris(listOf(incoming), shared = true)
            added.firstOrNull()?.let { viewing = it.name }
        }
    }

    val ui = rememberFileUi(vm) { viewing = it.name }
    val open: (PdfItem) -> Unit = { viewing = it.name }

    BackHandler(enabled = viewing != null || searching || dest != Dest.HOME) {
        when {
            searching -> searching = false
            viewing != null -> viewing = null
            else -> dest = Dest.HOME
        }
    }

    Box(Modifier.fillMaxSize().background(c.background)) {
        val v = viewing
        if (v != null) {
            ViewerScreen(vm, v, onBack = { viewing = null }, ui = ui)
        } else {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val wide = maxWidth >= 840.dp
                val nav: (Dest) -> Unit = { d ->
                    dest = d
                    if (!wide) scope.launch { drawer.close() }
                }
                val content: @Composable () -> Unit = {
                    Column(Modifier.fillMaxSize()) {
                        Header(
                            dest = dest, wide = wide, collapsed = collapsed, vm = vm,
                            onMenu = { if (wide) collapsed = !collapsed else scope.launch { drawer.open() } },
                            onSearch = { searching = true },
                            onNav = nav,
                        )
                        Box(Modifier.weight(1f).fillMaxWidth()) {
                            ScreenFor(dest, vm, ui, wide, nav, upload, open)
                        }
                    }
                }
                if (wide) {
                    Row(Modifier.fillMaxSize()) {
                        Sidebar(dest, nav, upload, collapsed, Modifier.width(if (collapsed) 76.dp else 250.dp))
                        Box(Modifier.weight(1f)) { content() }
                    }
                } else {
                    ModalNavigationDrawer(
                        drawerState = drawer,
                        drawerContent = {
                            ModalDrawerSheet(drawerContainerColor = c.sidebar, modifier = Modifier.width(290.dp)) {
                                Sidebar(dest, nav, { scope.launch { drawer.close() }; upload() }, false, Modifier.fillMaxSize())
                            }
                        },
                    ) { content() }
                }
            }
            if (searching) SearchDialog(vm, ui, onClose = { searching = false }, onOpen = { searching = false; open(it) })
        }
        ToastHost(vm.toast, vm::dismissToast, Modifier.align(Alignment.BottomCenter))
        FileDialogs(ui)
    }
}

@Composable
private fun ScreenFor(
    dest: Dest, vm: AppViewModel, ui: FileUi, wide: Boolean,
    nav: (Dest) -> Unit, upload: () -> Unit, open: (PdfItem) -> Unit,
) {
    when (dest) {
        Dest.HOME -> HomeScreen(vm, ui, wide, nav, upload)
        Dest.ALL, Dest.RECENT, Dest.STARRED, Dest.SHARED -> LibraryScreen(dest, vm, ui, wide, upload)
        Dest.SETTINGS -> SettingsScreen(vm, wide)
        Dest.HELP -> HelpScreen(wide)
        else -> ToolScreen(dest, vm, wide, open, nav)
    }
}

@Composable
private fun Sidebar(dest: Dest, onNav: (Dest) -> Unit, onNew: () -> Unit, collapsed: Boolean, modifier: Modifier) {
    val c = Pdfly.colors
    Column(
        modifier.background(c.sidebar).then(if (!c.dark) Modifier else Modifier)
            .statusBarsPadding().navigationBarsPadding().padding(horizontal = if (collapsed) 12.dp else 16.dp, vertical = 16.dp),
    ) {
        Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(38.dp).clip(Radius.md).background(c.primary), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.PictureAsPdf, null, tint = c.onPrimary, modifier = Modifier.size(22.dp))
            }
            if (!collapsed) Text("PDFly", style = Type.section.copy(fontWeight = FontWeight.Bold), color = c.text)
        }
        Spacer(Modifier.height(16.dp))
        if (collapsed) {
            IconBtn(Icons.Outlined.Add, "New PDF", onNew, tint = c.onPrimary, background = c.primary, size = 52.dp)
        } else {
            PButton("New PDF", onNew, Modifier.fillMaxWidth(), icon = Icons.Outlined.Add)
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            var last = ""
            for (d in Dest.values()) {
                if (d.group != last) {
                    last = d.group
                    if (!collapsed) Text(d.group, style = Type.small.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp), color = c.textMuted, modifier = Modifier.padding(start = 12.dp, top = 16.dp, bottom = 6.dp))
                    else Spacer(Modifier.height(12.dp))
                }
                NavItem(d, d == dest, collapsed) { onNav(d) }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 10.dp).clip(Radius.md).border(1.dp, c.border, Radius.md).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Avatar()
            if (!collapsed) {
                Column(Modifier.weight(1f)) {
                    Text("You", style = Type.bodyMedium, color = c.text, maxLines = 1)
                    Text("On-device · Private", style = Type.small, color = c.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconBtn(Icons.Outlined.Settings, "Open settings", { onNav(Dest.SETTINGS) }, size = 36.dp)
            }
        }
    }
}

@Composable
private fun NavItem(d: Dest, active: Boolean, collapsed: Boolean, onClick: () -> Unit) {
    val c = Pdfly.colors
    val fg = if (active) c.accentText else c.textSecondary
    Row(
        Modifier.fillMaxWidth().padding(vertical = 1.dp).height(44.dp).clip(Radius.md)
            .background(if (active) c.primarySoft else androidx.compose.ui.graphics.Color.Transparent)
            .clickable(role = Role.Tab, onClick = onClick)
            .semantics { selected = active; contentDescription = d.label }
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = if (collapsed) Arrangement.Center else Arrangement.spacedBy(12.dp),
    ) {
        Icon(d.icon, null, tint = fg, modifier = Modifier.size(20.dp))
        if (!collapsed) Text(d.label, style = if (active) Type.bodyMedium.copy(fontWeight = FontWeight.SemiBold) else Type.bodyMedium, color = if (active) c.accentText else c.text.copy(alpha = 0.82f), maxLines = 1)
    }
}

@Composable
private fun Avatar(size: androidx.compose.ui.unit.Dp = 36.dp) {
    val c = Pdfly.colors
    Box(Modifier.size(size).clip(CircleShape).background(c.primarySurface), contentAlignment = Alignment.Center) {
        Text("Y", style = Type.bodyMedium, color = c.accentText)
    }
}

@Composable
private fun Header(
    dest: Dest, wide: Boolean, collapsed: Boolean, vm: AppViewModel,
    onMenu: () -> Unit, onSearch: () -> Unit, onNav: (Dest) -> Unit,
) {
    val c = Pdfly.colors
    var menu by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().background(c.surface).statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().height(if (wide) 68.dp else 60.dp).padding(horizontal = if (wide) 20.dp else 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconBtn(if (wide) Icons.Outlined.ViewSidebar else Icons.Outlined.Menu, if (wide) (if (collapsed) "Expand sidebar" else "Collapse sidebar") else "Open navigation menu", onMenu)
            Spacer(Modifier.width(6.dp))
            Column(Modifier.weight(1f)) {
                if (wide) Text(dest.group.lowercase().replaceFirstChar { it.uppercase() }, style = Type.small, color = c.textMuted, maxLines = 1)
                Text(dest.label, style = Type.cardTitle, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconBtn(Icons.Outlined.Search, "Search PDFs", onSearch)
            val dark = vm.themeMode == ThemeMode.DARK || (vm.themeMode == ThemeMode.SYSTEM && c.dark)
            IconBtn(
                if (dark) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                if (dark) "Switch to light mode" else "Switch to dark mode",
                { vm.updateTheme(if (dark) ThemeMode.LIGHT else ThemeMode.DARK) },
            )
            Box {
                Box(Modifier.size(44.dp).clickable(role = Role.Button) { menu = true }.semantics { contentDescription = "Account menu" }, contentAlignment = Alignment.Center) { Avatar(34.dp) }
                DropdownMenu(menu, { menu = false }, containerColor = c.elevated, shape = Radius.md) {
                    DropdownMenuItem(text = { Text("Settings", style = Type.body, color = c.text) }, leadingIcon = { Icon(Icons.Outlined.Settings, null, tint = c.text, modifier = Modifier.size(18.dp)) }, onClick = { menu = false; onNav(Dest.SETTINGS) })
                    DropdownMenuItem(text = { Text("Help & Support", style = Type.body, color = c.text) }, leadingIcon = { Icon(Icons.Outlined.Info, null, tint = c.text, modifier = Modifier.size(18.dp)) }, onClick = { menu = false; onNav(Dest.HELP) })
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(c.border))
    }
}

@Composable
private fun SearchDialog(vm: AppViewModel, ui: FileUi, onClose: () -> Unit, @Suppress("UNUSED_PARAMETER") onOpen: (PdfItem) -> Unit) {
    val c = Pdfly.colors
    var q by remember { mutableStateOf("") }
    var starredOnly by remember { mutableStateOf(false) }
    val query = q.trim().lowercase()
    val results = vm.items.filter { item ->
        (!starredOnly || item.starred) && (query.isEmpty() ||
            item.name.lowercase().contains(query) ||
            com.pdfly.app.data.formatDate(item.modified).lowercase().contains(query) ||
            item.pagesLabel.lowercase().contains(query) ||
            com.pdfly.app.data.formatSize(item.size).lowercase().contains(query))
    }.let { vm.sorted(it) }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxSize().background(c.background).statusBarsPadding().navigationBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PdfTextField(q, { q = it }, "Search by name, date, size or pages", Modifier.weight(1f), leading = Icons.Outlined.Search, label = "Search PDFs")
                IconBtn(Icons.Outlined.Close, "Close search", onClose)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("All", !starredOnly) { starredOnly = false }
                Chip("Starred", starredOnly) { starredOnly = true }
            }
            Text("Searches file names and details. Searching inside PDF text isn't available.", style = Type.small, color = c.textMuted)
            if (results.isEmpty()) {
                EmptyState(
                    Icons.Outlined.Search,
                    if (vm.items.isEmpty()) "No PDFs yet" else "No results found",
                    if (vm.items.isEmpty()) "Upload a PDF and it will show up here." else "Try a different name or clear the filter.",
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(results, key = { it.path }) { item ->
                        FileRow(item, ui)
                    }
                }
            }
        }
    }
}

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    val c = Pdfly.colors
    Box(
        Modifier.height(36.dp).clip(CircleShape)
            .background(if (selected) c.primarySoft else c.surface)
            .border(1.dp, if (selected) c.primary else c.border, CircleShape)
            .clickable(role = Role.RadioButton, onClick = onClick)
            .semantics { this.selected = selected }
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = Type.secondary.copy(fontWeight = FontWeight.Medium), color = if (selected) c.accentText else c.textSecondary, maxLines = 1)
    }
}
